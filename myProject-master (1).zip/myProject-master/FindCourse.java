/*
 * Displays a list of previously created courses.
 */
package myproject;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 *
 * @author Evelyn He
 */
public class FindCourse extends MyProject {

    private JFrame findCourse;
    private final JPanel bodyPanel = new JPanel();
    private final GridLayout bodyLayout = new GridLayout(10, 0);

    private ArrayList<JButton> btns = new ArrayList<>();
    private String line;
    private BufferedReader br;
    private StringBuilder sb = new StringBuilder();

    public FindCourse() throws IOException {

        findCourse = frame(0,0,455, 390, 3);
        super.title(" Find A Course", findCourse, super.titleFontSize, 0, true);

        bodyPanel.setBounds(10, 48, 415, 286);
        bodyPanel.setLayout(bodyLayout);
        bodyPanel.setBackground(gray);
        
        JScrollPane scrollPane = new JScrollPane(bodyPanel);
        scrollPane.setBounds(10,48,415,286);

        //Checks to see if any courses have been created yet
        Boolean hasFiles = findFile();
        if (!hasFiles) {
            JLabel noCourses = new JLabel(" No existing courses.");
            bodyPanel.add(noCourses);

        }

        findCourse.add(scrollPane);
        findCourse.setVisible(true);
    }

    //Gets course codes from course-list file and displays them on arraylist of JButtons
    private boolean findFile() throws FileNotFoundException, IOException {

        int i = 0;
        File courseList = new File("Course-list.txt");

        if (courseList.exists()) {
            br = new BufferedReader(new FileReader("Course-list.txt"));

            try {
                sb = new StringBuilder();
                line = br.readLine();

                while (line != null) {
                    sb.append(line);
                    line = br.readLine();

                    //Creates new JButton
                    if (line != null) {
                        JButton a = new JButton(line);
                        a.addActionListener(actions);
                        bodyPanel.add(a);
                        btns.add(i, a);
                        i++;
                    }
                }

                if (i == 0) {
                    return false;
                }

            } catch (IOException ex) {
                System.out.println(ex);
            }
            br.close();
            return true;
        }
        return false;
    }//end of findFile()

    //Passes course code to CreateCourse class on button click
    public ActionListener actions = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            JButton btn = (JButton) e.getSource();
            findCourse.dispose();
            try {
                new CreateCourse(btn.getText());
            } catch (IOException ex) {
                Logger.getLogger(FindCourse.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    };//end of ActionListener()

}//end of FindCourse class
