package myproject;

/*
 * This is the main class of the project and contains the main method. It also
 * contains some frequently used methods.
 */


import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.Border;

/**
 * @author Evelyn He
 *
 */
public class MyProject extends AbstractAction {

    int titleHeight = 38;
    int titleFontSize = 25;
    int fontSize = 23;

    Color darkGreen = new Color(11, 102, 35);
    Color white = new Color(238, 238, 238);
    Color lightGreen = new Color(46, 192, 121);
    Color gray = new Color(169, 169, 169);

    Border blackline = BorderFactory.createLineBorder(Color.black);

    public JFrame frame(int x, int y, int w, int h, int exit) { //Creates JFrame

        JFrame frame = new JFrame();
        frame.setSize(w, h);
        frame.setResizable(false);
        frame.setLocation(x, y);
        frame.setLayout(null);
        
        ImageIcon logo = new ImageIcon("logo.png");
        frame.setIconImage(logo.getImage());

        if (exit == 1) {
            frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        } else if (exit == 2) {
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        } else {
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }

        return frame;
    }//end of frame()

    public void title(String s, JFrame j, int fnt, int add, boolean addBtn) { //Creates header of UI

        JPanel titlePanel = new JPanel();
        titlePanel.setBounds(0, 0, j.getWidth(), titleHeight + add);
        titlePanel.setLayout(null);
        titlePanel.setBackground(darkGreen);

        JLabel title = new JLabel(s);
        title.setBounds(0, 0, j.getWidth() - 35, titleHeight + add);
        title.setForeground(white);
        title.setFont(title.getFont().deriveFont((float) (fnt)));
        titlePanel.add(title);

        if (addBtn) {
            ImageIcon scaled = new ImageIcon("home-button.png");
            Image image = scaled.getImage();
            Image unscaled = image.getScaledInstance(30, 30, java.awt.Image.SCALE_SMOOTH);
            scaled = new ImageIcon(unscaled);
            
            ImageIcon scaled2 = new ImageIcon("rollover-home-button.png");
            Image image2 = scaled2.getImage();
            Image unscaled2 = image2.getScaledInstance(30, 30, java.awt.Image.SCALE_SMOOTH);
            scaled2 = new ImageIcon(unscaled2);


            JButton home = new JButton(new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    j.dispose();
                    Homescreen h = new Homescreen();
                }
            });

            home.setIcon(scaled);
            home.setRolloverIcon(scaled2);

            home.setBounds(titlePanel.getWidth() - 60, 5, 30, 30);
            home.setBackground(darkGreen);
            titlePanel.add(home);
        }

        j.add(titlePanel);
    }//end of title()

    public void label(int x, int y, int w, int h, String s, JPanel p, JFrame f) {

        JLabel l = new JLabel(s);
        l.setBounds(x, y, w, h);
        Font newLabelFont = new Font(l.getFont().getName(), Font.PLAIN, 12);
        l.setFont(newLabelFont);
        if (p != null) {
            p.add(l);
        } else {
            f.add(l);
        }
    }//end of label()

    public JTextField textfield(int x, int y, int w, int h, JPanel p, JFrame f, String val) {

        JTextField t = new JTextField(val);
        t.setBounds(x, y, w, h);
        if (p != null) {
            p.add(t);
        } else {
            f.add(t);
        }
        return t;
    }

    public static void main(String args[]) {

        try {
            for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | UnsupportedLookAndFeelException e) {
            System.out.println(e);
        }
        new SplashScreen();

    }//end of main method

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println(e);
    }
}//end of myProject Class
