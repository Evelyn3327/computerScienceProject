/*
 * Creates a UI which allows user to create new courses of edit already-created
 * ones. Contains three JTables - One to display the course's expectations, one
 * to display students, and one to display tasks.
 */
package myproject;

import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

/**
 * @author Evelyn He
 *
 */
public final class CreateCourse extends MyProject implements TableModelListener {

    int numOfExp = 0;
    int numOfStudents = 0;
    int numCourses = 0;

    boolean isNewCourse = true;
    String courseCode, courseTitle;
    ArrayList<Expectation> expectations = new ArrayList();
    LinkedHashMap<String, Student> students = new LinkedHashMap();
    ArrayList<GeneralTask> generalTasks = new ArrayList();
    Integer[] numTaskType = new Integer[4];

    String labels[] = {"1", "2", "3", "4","5","6"};
    ArrayList<Checkbox> spExp = new ArrayList<>();
    ArrayList<String> readdata = new ArrayList<>();

    char ascii = 65;
    String[][] data = new String[0][3];

    boolean dataHasChanged = false;

    public CreateCourse(String selectedCourse) throws IOException {

        JPanel expPnl = new JPanel(new BorderLayout());
        expPnl.setBounds(10, 140, 470, 150);
        expPnl.setBackground(Color.LIGHT_GRAY);

        JPanel cbPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        cbPnl.setBounds(620, 230, 200, 30);

        JPanel studentPnl = new JPanel(new BorderLayout());
        studentPnl.setBounds(10, 310, 470, 200);
        studentPnl.setBackground(Color.LIGHT_GRAY);

        JPanel taskPnl = new JPanel(new BorderLayout());
        taskPnl.setBounds(10, 530, 470, 150);
        taskPnl.setBackground(Color.LIGHT_GRAY);

        JFrame courseFrame = super.frame(0,0,840, 765, 1);

        //Checks if it is a newly created course
        if (!"".equals(selectedCourse) && selectedCourse != null) {
            isNewCourse = false;
            super.title(" " + selectedCourse, courseFrame, super.titleFontSize, 0, true);
            loadCourse(selectedCourse);

        } else {
            super.title(" Create A Course", courseFrame, super.titleFontSize, 0, true);
            for (int i = 0; i < 4; i++) {
                numTaskType[i] = 0;
            }

        }

        label(20, super.titleHeight + 20, 100, 20, "Course Code: ", null, courseFrame);
        JTextField txtCourseCode = textfield(110, super.titleHeight + 15, 200, 30, null, courseFrame, selectedCourse);
        label(20, titleHeight + 55, 100, 20, "Course Name: ", null, courseFrame);
        JTextField txtCourseName = textfield(110, titleHeight + 52, 200, 30, null, courseFrame, courseTitle);
        
        if(!isNewCourse){
            txtCourseCode.setEditable(false);
        }
        

        DefaultTableModel expTable = expectations(courseFrame, expPnl, cbPnl);
        DefaultTableModel studentTable = students(courseFrame, studentPnl);
        DefaultTableModel taskTable = tasks(courseFrame, taskPnl, txtCourseCode);

        //button which saves information to file and calls new class when clicked
        JButton submit = new JButton(new AbstractAction("Submit") {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (generalTasks.size() > 0 && students.size() > 0) {
                    if (isNewCourse) {
                        saveNewCourse(txtCourseCode, txtCourseName, studentTable, expTable, taskTable);
                        courseFrame.dispose();
                        //new FindCourse();
                        new CourseExpectation(txtCourseCode.getText(), txtCourseName.getText(),
                                expectations, students, generalTasks, numTaskType);
                    } else {
                        if (dataHasChanged) {
                            saveOldCourse(txtCourseCode, txtCourseName, studentTable, expTable, taskTable);
                        }
                        courseFrame.dispose();
                        new CourseExpectation(txtCourseCode.getText(), txtCourseName.getText(),
                                expectations, students, generalTasks, numTaskType);
                    }
                } else {
                    new Popups().fieldLeftEmpty();
                }

            }
        });
        submit.setBounds(730, 680, 80, 30);

        //button which deletes selected course
        JButton delete = new JButton(new AbstractAction("Delete Course") {
            @Override
            public void actionPerformed(ActionEvent ex) {
                ArrayList<String> createdCourses = new ArrayList();

                File listFile = new File("Course-list.txt");
                File courseFile = new File(txtCourseCode.getText() + ".txt");
                String courseCode = txtCourseCode.getText();

                BufferedReader br;

                //puts lines from old file into arraylist
                try {
                    br = new BufferedReader(new FileReader("Course-list.txt"));
                    String line = br.readLine();

                    while (line != null) {
                        if (!"".equals(line)) {
                            createdCourses.add(line);
                        }
                        line = br.readLine();
                    }

                    br.close();

                } catch (IOException e) {
                    Logger.getLogger(CreateCourse.class.getName()).log(Level.SEVERE, null, ex);
                }

                //removes selected course from arraylist
                for (int i = 0; i < createdCourses.size(); i++) {
                    if (createdCourses.get(i).equals(courseCode)) {
                        createdCourses.set(i, "");

                    }
                }

                listFile.delete();
                courseFile.delete();

                //puts elements of arraylist into new file with the same name
                File courseList = new File("Course-list.txt");
                try {
                    try (FileWriter courseListWriter = new FileWriter(courseList)) {
                        for (int i = 0; i < createdCourses.size(); i++) {
                            if (!"".equals(createdCourses.get(i))) {
                                courseListWriter.write("\r\n" + createdCourses.get(i));
                            }
                        }
                    }

                } catch (IOException e) {
                    Logger.getLogger(CreateCourse.class.getName()).log(Level.SEVERE, null, ex);
                }

                new Popups().deleted(courseFrame);
            }
        });
        delete.setBounds(700, super.titleHeight + 15, 110, 30);

        courseFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (dataHasChanged) {
                    new Popups().confirmExit();
                } else {
                    System.exit(0);
                }
            }
        });

        courseFrame.add(submit);

        if (!isNewCourse) {
            courseFrame.add(delete);
        }

        courseFrame.setVisible(true);

    } //end of constructor

    //reads from textfile and stores information as strings, arraylists, and linkedhashmaps
    private void loadCourse(String selectedCourse) throws FileNotFoundException, IOException {

        BufferedReader br = new BufferedReader(new FileReader(selectedCourse + ".txt"));
        String line = br.readLine();
        String studentNumber = "";

        try {
            while (line != null) {

                if (!"".equals(line)) {
                    String valueType = line.substring(0, 2);
                    String info = line.substring(3);

                    switch (valueType) {
                        case "CC":
                            courseCode = line.substring(3);
                            break;

                        case "CN":
                            courseTitle = line.substring(3);
                            break;

                        case "CE":
                            ascii++;
                            String expParts[] = info.split("%");
                            String[] expSpecifics = expParts[2].split(",");
                            Expectation expExpectations = new Expectation(expParts[0], expParts[1], expSpecifics);
                            expectations.add(expExpectations);
                            break;

                        case "CS":
                            String sdntParts[] = info.split("%");
                            studentNumber = sdntParts[0];
                            Student sdntExpectations = new Student(sdntParts[0], sdntParts[1], sdntParts[2], new LinkedHashMap());
                            students.put(sdntParts[0], sdntExpectations);
                            break;

                        case "CT":
                            String taskParts[] = info.split("%");
                            String[] taskSpecifics = taskParts[2].split(",");
                            GeneralTask taskDesc = new GeneralTask(taskParts[0], taskParts[1], taskSpecifics);
                            generalTasks.add(taskDesc);
                            break;

                        case "SM":
                            String markParts[] = info.split("%");
                            students.get(studentNumber).marks.put(markParts[0], markParts[1]);
                            break;

                        case "TN":
                            String[] temp = info.split("%");
                            for (int i = 0; i < 4; i++) {
                                numTaskType[i] = Integer.parseInt(temp[i]);
                            }
                            break;

                    }

                }
                line = br.readLine();

            }

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            br.close();
        }
    }//end of loadCourse()

    //Creates table to display old expectations and functionality to add new ones
    public DefaultTableModel expectations(JFrame courseFrame, JPanel expPnl,
            JPanel cbPnl) {

        //Creating textfields and their labels
        JLabel expTitle = new JLabel(" Course Expectations");
        label(500, 165, 120, 20, "Overall Expectation:", null, courseFrame);
        label(500, 200, 120, 20, "Expectation Name:", null, courseFrame);
        label(500, 235, 120, 20, "Specific Expectations:", null, courseFrame);

        JTextField strand = textfield(620, 160, 190, 30, null, courseFrame, Character.toString(ascii));
        JTextField strandName = textfield(620, 195, 190, 30, null, courseFrame, null);

        for (int i = 0; i < labels.length; i++) {
            Checkbox checkbox = new Checkbox(labels[i]);
            spExp.add(checkbox);
            cbPnl.add(checkbox);
        }

        //Creating expectations table
        DefaultTableModel expModel = new DefaultTableModel();
        JTable expTable = new JTable(expModel) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        expModel.addColumn("Overall Expectation");
        expModel.addColumn("Expectation Name");
        expModel.addColumn("Specific Expecations");

        expTable.getColumnModel().getColumn(0).setPreferredWidth(125);
        expTable.getColumnModel().getColumn(1).setPreferredWidth(150);
        expTable.getColumnModel().getColumn(2).setPreferredWidth(175);

        JScrollPane scrollPane = new JScrollPane(expTable);
        expPnl.add(expTitle, BorderLayout.NORTH);
        expPnl.add(scrollPane, BorderLayout.CENTER);

        for (int rowNum = 0; rowNum < expectations.size(); rowNum++) {
            String specificsToString = "";

            for (int i = 0; i < expectations.get(rowNum).specificExpectations.length; i++) {
                specificsToString = specificsToString + "," + expectations.get(rowNum).specificExpectations[i];
            }

            //adds information from expectations arraylist to table
            expModel.addRow(new Object[]{
                expectations.get(rowNum).strand,
                expectations.get(rowNum).strandName,
                specificsToString.substring(1)
            });
        }
        int rowCount = expTable.getRowCount();

        //Sets which row of the table is highlighted
        if (rowCount > 0) {
            expTable.setRowSelectionInterval(rowCount - 1, rowCount - 1);
        }

        JButton addRow = new JButton(new AbstractAction("Add Row") {
            String temp = "";
            boolean checked = false;

            public void actionPerformed(ActionEvent e) {
                dataHasChanged = true;

                numOfExp++;

                //converts information from checkboxes into a string
                for (int i = 0; i < labels.length; i++) {
                    if (spExp.get(i).getState() == true) {
                        if (checked == true) {
                            temp = temp + "," + ascii + Integer.toString(i + 1);
                        } else {
                            temp = ascii + Integer.toString(i + 1);
                            checked = true;
                        }
                    }
                }

                String nextRow = Integer.toString(expModel.getRowCount());

                //adds row to table
                expModel.addRow(new Object[]{
                    strand.getText(),
                    strandName.getText(),
                    temp});

                setSelection(expTable);

                String[] expSpecifics = temp.split(",");

                //adds expectation to expectations arraylist
                Expectation expExpectations = new Expectation(strand.getText(), strandName.getText(), expSpecifics);
                expectations.add(expExpectations);

                if (ascii < 90) {
                    ascii++;
                }

                //Clears textfields and checkboxes
                strand.setText(Character.toString(ascii));
                strandName.setText(null);

                for (int i = 0; i < labels.length; i++) {
                    spExp.get(i).setState(false);
                }

                temp = "";
                checked = false;
            }
        });
        addRow.setBounds(500, 270, 100, 20);

        courseFrame.add(addRow);
        courseFrame.add(expPnl);
        courseFrame.add(cbPnl);
        return expModel;
    }//end of expectations()

    //Creates table to display previously created students and functionality to add new ones
    public DefaultTableModel students(JFrame courseFrame, JPanel studentPnl) {

        JLabel studentTitle = new JLabel(" Students");
        label(500, 335, 120, 20, "Student Number: ", null, courseFrame);
        label(500, 370, 100, 20, "First Name:", null, courseFrame);
        label(500, 405, 100, 20, "Last Name:", null, courseFrame);

        JTextField studentNum = textfield(620, 330, 190, 30, null, courseFrame, null);
        JTextField studentFirst = textfield(620, 365, 190, 30, null, courseFrame, null);
        JTextField studentLast = textfield(620, 400, 190, 30, null, courseFrame, null);

        //Creates student table
        DefaultTableModel studentModel = new DefaultTableModel();
        JTable studentTable = new JTable(studentModel) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        studentModel.addColumn("Student Number");
        studentModel.addColumn("First Name");
        studentModel.addColumn("Last Name");

        studentTable.getColumnModel().getColumn(0).setPreferredWidth(200);
        studentTable.getColumnModel().getColumn(1).setPreferredWidth(125);
        studentTable.getColumnModel().getColumn(2).setPreferredWidth(125);

        JScrollPane scrollPane = new JScrollPane(studentTable);

        studentPnl.add(studentTitle, BorderLayout.NORTH);
        studentPnl.add(scrollPane, BorderLayout.CENTER);

        //Populates table with information from the student linkedhashmap
        for (Map.Entry item : students.entrySet()) {
            Student theStudent = (Student) item.getValue();

            studentModel.addRow(new Object[]{
                theStudent.studentNumber,
                theStudent.firstName,
                theStudent.lastName
            });
        }

        setSelection(studentTable);

        JButton addRow = new JButton(new AbstractAction("Add Row") {

            public void actionPerformed(ActionEvent e) {
                dataHasChanged = true;
                numOfStudents++;

                //adds new Student to the student linkedhashmap
                Student sdnt = new Student(studentNum.getText(), studentFirst.getText(), studentLast.getText(), new LinkedHashMap());
                students.put(studentNum.getText(), sdnt);

                //adds row to table
                studentModel.addRow(new Object[]{
                    studentNum.getText(),
                    studentFirst.getText(),
                    studentLast.getText()});

                studentNum.setText(null);
                studentFirst.setText(null);
                studentLast.setText(null);

                setSelection(studentTable);
            }

        });
        addRow.setBounds(500, 440, 100, 20);

        JButton deleteRow = new JButton(new AbstractAction("Delete Row") {
            @Override
            public void actionPerformed(ActionEvent e) {
                dataHasChanged = true;
                int selectedRow = studentTable.getSelectedRow();
                String key = studentModel.getValueAt(selectedRow, 0).toString();
                studentModel.removeRow(selectedRow);
                setSelection(studentTable);
                students.remove(key);
            }
        });
        deleteRow.setBounds(620, 440, 100, 20);

        courseFrame.add(studentPnl);
        courseFrame.add(addRow);
        courseFrame.add(deleteRow);

        return studentModel;

    }//end of students()

    //Creates table to display previously created tasks and functionality to add new ones
    public DefaultTableModel tasks(JFrame courseFrame, JPanel taskPnl, JTextField code) {
        JLabel taskTitle = new JLabel(" Tasks");

        //Creates task table
        DefaultTableModel taskModel = new DefaultTableModel();
        JTable taskTable = new JTable(taskModel) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        taskModel.addColumn("Task Name");
        taskModel.addColumn("Task Type");
        taskModel.addColumn("Task Expectations");

        taskTable.getColumnModel().getColumn(0).setPreferredWidth(125);
        taskTable.getColumnModel().getColumn(1).setPreferredWidth(125);
        taskTable.getColumnModel().getColumn(2).setPreferredWidth(200);

        JScrollPane scrollPane = new JScrollPane(taskTable);

        //populates task table with information from the generalTasks arraylist
        for (int i = 0; i < generalTasks.size(); i++) {
            GeneralTask aTask = generalTasks.get(i);
            String specifics = "";
            for (int j = 0; j < aTask.taskExpectations.length; j++) {
                specifics = specifics + "," + aTask.taskExpectations[j];
            }
            String substring = specifics.substring(1);
            taskModel.addRow(new Object[]{
                aTask.taskName,
                aTask.taskType,
                substring
            });
        }
        setSelection(taskTable);

        //On button click, a new UI (which allows user to create a task) pops up
        JButton addRow = new JButton(new AbstractAction("+ Add A Task") {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Task task = new Task(code.getText(), taskModel, expectations, generalTasks, numTaskType);
                    dataHasChanged = true;
                } catch (IOException ex) {
                    Logger.getLogger(CreateCourse.class.getName()).log(Level.SEVERE, null, ex);
                }
                setSelection(taskTable);
            }
        });
        addRow.setBounds(500, 550, 100, 35);

        JButton deleteRow = new JButton(new AbstractAction("Delete Row") {
            @Override
            public void actionPerformed(ActionEvent e) {
                dataHasChanged = true;
                int selectedRow = taskTable.getSelectedRow();
                taskModel.removeRow(selectedRow);
                generalTasks.remove(selectedRow);
                setSelection(taskTable);
            }
        });
        deleteRow.setBounds(500, 590, 100, 20);

        taskPnl.add(taskTitle, BorderLayout.NORTH);
        taskPnl.add(scrollPane, BorderLayout.CENTER);

        courseFrame.add(taskPnl);
        courseFrame.add(addRow);
        courseFrame.add(deleteRow);
        return taskModel;

    }//end of tasks()

    //sets the highlighted row of a table to its last row
    public void setSelection(JTable t) {
        int rowCount = t.getRowCount();
        if (rowCount > 0) {
            t.setRowSelectionInterval(rowCount - 1, rowCount - 1);
        }
    }//end of setSelection

    //saves edited information from a previously created course.
    public void saveOldCourse(JTextField code, JTextField name,
            DefaultTableModel studentTable, DefaultTableModel expTable,
            DefaultTableModel taskTable) {

        //replaces disposes of old file and creates a new one
        File oldFile = new File(code.getText() + ".txt");
        String[] filePath = oldFile.getAbsolutePath().split(code.getText());
        oldFile.delete();

        File newFile = new File(code.getText() + ".txt");
        try {
            newFile.createNewFile();
        } catch (IOException ex) {
            Logger.getLogger(CreateCourse.class.getName()).log(Level.SEVERE, null, ex);
        }

        //Writes edited information into the new file.
        FileWriter fw = null;
        BufferedWriter bw = null;
        PrintWriter pw = null;

        try {
            fw = new FileWriter(newFile);
            bw = new BufferedWriter(fw);
            pw = new PrintWriter(bw);

            pw.println("CC " + code.getText());
            pw.println("");
            pw.println("CN " + name.getText());
            pw.println("");

            writeTableToFile("CE ", expTable, pw);
            pw.print("TN ");
            for (int i = 0; i < 4; i++) {
                pw.print(numTaskType[i] + "%");
            }
            pw.println("");
            writeTableToFile("CT ", taskTable, pw);

            for (Map.Entry item : students.entrySet()) {
                pw.print("CS ");
                Student theStudent = (Student) item.getValue();
                pw.print(theStudent.studentNumber + "%");
                pw.print(theStudent.firstName + "%");
                pw.println(theStudent.lastName + "%");

                if (!theStudent.marks.isEmpty()) {
                    for (Map.Entry taskMarks : theStudent.marks.entrySet()) {
                        pw.print("SM ");
                        pw.print(taskMarks.getKey() + "%");
                        pw.println(taskMarks.getValue() + "%");
                    }
                }
            }

        } catch (IOException e) {
            System.out.println(e);

            System.out.println(e);
        } finally {
            try {
                if (fw != null && bw != null && pw != null) {
                    bw.close();
                    fw.close();
                    pw.close();
                }
            } catch (IOException e) {
                System.out.println(e);
            }
        }
    }//end of saveOldCourse()

    //creates a new file and writes user-entered information into the file.
    public void saveNewCourse(JTextField code, JTextField name,
            DefaultTableModel studentTable, DefaultTableModel expTable,
            DefaultTableModel taskTable) {

        //Creates file for newly created course
        Path newCourse = Paths.get(code.getText() + ".txt");
        final Path courseList;

        //Creates course-list file which contains codes of all created courses
        if (!Files.exists(newCourse)) {
            try {
                if (!Files.exists(Paths.get("Course-list"))) {
                    courseList = Paths.get("Course-list");

                }
                FileWriter courseListWriter = new FileWriter("Course-list.txt", true);
                courseListWriter.write("\r\n" + code.getText());
                courseListWriter.close();

            } catch (IOException ex) {
                Logger.getLogger(CreateCourse.class.getName()).log(Level.SEVERE, null, ex);
            }

            //Writes to the specific course's file
            FileWriter fw = null;
            BufferedWriter bw = null;
            PrintWriter pw = null;

            try {
                fw = new FileWriter(code.getText() + ".txt");
                bw = new BufferedWriter(fw);
                pw = new PrintWriter(bw);

                pw.println("CC " + code.getText());
                pw.println("");
                pw.println("CN " + name.getText());
                pw.println("");

                writeTableToFile("CE ", expTable, pw);

                pw.print("TN ");
                for (int i = 0; i < 4; i++) {
                    pw.print(numTaskType[i] + "%");
                }
                pw.println("");

                writeTableToFile("CT ", taskTable, pw);
                writeTableToFile("CS ", studentTable, pw);

            } catch (IOException e) {
                System.out.println(e);

                System.out.println(e);
            } finally {
                try {
                    if (fw != null && bw != null && pw != null) {
                        bw.close();
                        fw.close();
                        pw.close();
                    }
                } catch (IOException e) {
                    System.out.println(e);
                }
            }
        }
    }//end of saveNewCourse()

    //method to write information from tables to a file
    public void writeTableToFile(String s, DefaultTableModel table, PrintWriter pw) {
        for (int rowCount = 0; rowCount < table.getRowCount(); rowCount++) {
            pw.print(s);
            for (int columnCount = 0; columnCount < 3; columnCount++) {
                pw.print(table.getValueAt(rowCount, columnCount).toString() + "%");
            }
            pw.println("");
        }
        pw.println("");
    }//end of writeTableToFile()

    @Override
    public void tableChanged(TableModelEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}//end of CreateCourse class
