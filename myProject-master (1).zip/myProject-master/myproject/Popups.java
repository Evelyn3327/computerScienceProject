/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myproject;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author earl
 */
public class Popups {

    public void emptySections() {
        JFrame frame = new JFrame();
        frame.setLayout(new BorderLayout());
        frame.setSize(200, 100);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel txtHolder = new JPanel(new FlowLayout());
        ImageIcon warning = new ImageIcon(getClass().getResource("image.png"));
        JLabel text = new JLabel("Missing of empty fields");
        JLabel warningLabel = new JLabel(warning);

        txtHolder.add(warningLabel, text);

        JPanel btnHolder = new JPanel(new FlowLayout());
        
        JButton ok = new JButton(new AbstractAction("Ok") {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });

    }

    public void cancelOrSave() {

    }

    public void sucessfulSave() {

    }

}
