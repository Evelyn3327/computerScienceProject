/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myproject;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Evelyn He
 *
 */
public class Task extends MyProject {

    JFrame taskFrame;
    JPanel btnHolder;
    JPanel expHolder;

    boolean addItems;

    JTextField taskName;
    ButtonGroup taskTypeBTN = new ButtonGroup();
    JRadioButton t;
    JRadioButton a;
    JRadioButton q;
    JRadioButton s;

    JButton submit;
    ArrayList<String> lines = new ArrayList<>();

    public ArrayList<JCheckBox> specificStrand = new ArrayList<>();
    int lineCount = 0;
    GridBagConstraints c = new GridBagConstraints();

    public String taskType = "";
    public String selections = "";

    Task(String coursePressed, DefaultTableModel taskModel, ArrayList<Expectation> expectations,
            ArrayList<GeneralTask> generalTasks) throws FileNotFoundException, IOException {

        int numLines = expectations.size();
        addItems = true;

        if (numLines == 0) {
            numLines = 1;
            addItems = false;
        }

        final boolean CREATE_TASK = addItems;

        taskFrame = super.Frame(446, 250 + numLines * 25, false);

        super.Title(" Create A Task - " + coursePressed, taskFrame, super.titleFontSize, 0);

        //Creating textfields for user to enter in Task Name
        if (addItems) {
            label(10, 45, 100, 20, "Task Name:", null, taskFrame);
            taskName = textfield(90, 45, 200, 25, null, taskFrame, null);
        }

        //Makes an arraylist of buttons for user to choose task type.
        if (addItems) {
            label(10, 80, 100, 20, "Task Type: ", null, taskFrame);
        }
        btnHolder = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnHolder.setBounds(80, 77, 350, 25);

        t = new JRadioButton("Test", true);
        a = new JRadioButton("Assignment");
        q = new JRadioButton("Quiz");
        s = new JRadioButton("Summative");

        taskTypeBTN.add(t);
        taskTypeBTN.add(a);
        taskTypeBTN.add(q);
        taskTypeBTN.add(s);

        btnHolder.add(t);
        btnHolder.add(a);
        btnHolder.add(q);
        btnHolder.add(s);

        expHolder = new JPanel(new GridLayout(numLines, 0));
        if (addItems) {
            expHolder.setBounds(10, 150, 410, numLines * 25);
        } else {
            expHolder.setBounds(10, 45, 410, numLines * 25);
        }
        expHolder.setBorder(blackline);

        //Adds a description of what to do
        JLabel description = new JLabel(" Assign expectations the task");

        Font labelFont = new Font(description.getFont().getName(), Font.PLAIN, 18);
        description.setFont(labelFont);
        description.setBounds(10, 120, 410, 30);
        description.setForeground(white);
        description.setBackground(darkGreen);
        description.setOpaque(true);

        //Adds a submit button
        submit = new JButton(new AbstractAction("Done") {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (CREATE_TASK) {
                    for (int cbSelected = 0; cbSelected < specificStrand.size(); cbSelected++) {
                        if (specificStrand.get(cbSelected).isSelected()) {
                            selections = selections + "," + specificStrand.get(cbSelected).getText();
                        }
                    }
                    selections = selections.substring(1);

                    String[] selectionsArray = selections.split(",");

                    if (t.isSelected()) {
                        taskType = t.getText();
                    } else if (a.isSelected()) {
                        taskType = a.getText();
                    } else if (q.isSelected()) {
                        taskType = q.getText();
                    } else if (s.isSelected()) {
                        taskType = s.getText();
                    }

                    taskModel.addRow(new Object[]{
                        taskName.getText(),
                        taskType,
                        selections
                    });

                    GeneralTask newTask = new GeneralTask(taskName.getText(), taskType, selectionsArray);
                    generalTasks.add(newTask);
                }

                taskFrame.dispose();

            }
        });
        submit.setBounds(347, 160 + numLines * 25, 75, 35);

        //read the course's file to add information to the JTable
        getSpecificExpectations(expectations, expHolder);

        //adding everything to the JPanel
        if (addItems) {
            taskFrame.add(btnHolder);
            taskFrame.add(description);
        }

        taskFrame.add(expHolder);
        taskFrame.add(submit);

        taskFrame.setVisible(true);
    }

    public void getSpecificExpectations(ArrayList<Expectation> e, JPanel p) {

        if (e.size() > 0) {
            for (int i = 0; i < e.size(); i++) {

                JPanel strand = new JPanel(new FlowLayout(FlowLayout.LEFT));
                strand.setBackground(gray);
                JLabel label = new JLabel(e.get(i).strand + ": " + e.get(i).strandName);
                strand.add(label);

                for (String s : e.get(i).specificExpectations) {
                    addToPanel(s, strand);
                }
                p.add(strand);
            }
        } else {
            JLabel label = new JLabel(" Add expectations to the course before creating a task.");
            p.add(label);
        }
    }

    public void addToPanel(String s, JPanel p) {
        JCheckBox cl = new JCheckBox(s);
        specificStrand.add(cl);
        p.add(cl);
    }
}