/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myproject;

import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

/**
 * @author Evelyn He
 *
 */
public final class CreateCourse extends MyProject implements TableModelListener {

    int numOfExp = 0;
    int numOfStudents = 0;
    int numCourses = 0;

    boolean isNewCourse = true;
    String courseCode, courseTitle;
    ArrayList<Expectation> expectations = new ArrayList();
    LinkedHashMap<String, Student> students = new LinkedHashMap();
    ArrayList<GeneralTask> generalTasks = new ArrayList();

    String labels[] = {"1", "2", "3", "4", "5", "6"};
    ArrayList<Checkbox> spExp = new ArrayList<>();
    ArrayList<String> readdata = new ArrayList<>();

    char ascii = 65;
    String[][] data = new String[0][3];

    public CreateCourse(String selectedCourse) throws IOException {

        JPanel panel1 = new JPanel(new BorderLayout());
        panel1.setBounds(10, 140, 470, 150);
        panel1.setBackground(Color.LIGHT_GRAY);

        JPanel panel2 = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panel2.setBounds(630, 230, 180, 30);

        JPanel panel3 = new JPanel(new BorderLayout());
        panel3.setBounds(10, 310, 470, 200);
        panel3.setBackground(Color.LIGHT_GRAY);

        JPanel panel4 = new JPanel(new BorderLayout());
        panel4.setBounds(10, 530, 470, 150);
        panel4.setBackground(Color.LIGHT_GRAY);

        //create JFrame
        JFrame courseFrame = super.Frame(845, 750, true);

        //See if course has been created already
        if (!"".equals(selectedCourse) && selectedCourse != null) {
            isNewCourse = false;
            super.Title(" " + selectedCourse, courseFrame, super.titleFontSize, 0);
            loadCourse(selectedCourse);

        } else {
            super.Title(" Create A Course", courseFrame, super.titleFontSize, 0);
        }

        //create overall labels
        label(20, super.titleHeight + 20, 100, 20, "Course Code: ", null, courseFrame);
        JTextField txtCourseCode = textfield(125, super.titleHeight + 15, 200, 30, null, courseFrame, selectedCourse);
        label(20, titleHeight + 55, 100, 20, "Course Name: ", null, courseFrame);
        JTextField txtCourseName = textfield(125, titleHeight + 52, 200, 30, null, courseFrame, courseTitle);

        DefaultTableModel expTable = expectationTable(courseFrame, panel1, panel2);
        DefaultTableModel studentTable = studentTable(courseFrame, panel3);
        DefaultTableModel taskTable = taskTable(courseFrame, panel4, txtCourseCode);

        JButton submit = new JButton(new AbstractAction("Submit") {
            public void actionPerformed(ActionEvent e) {

                if (isNewCourse) {
                    saveNewCourse(txtCourseCode, txtCourseName, studentTable, expTable, taskTable);
                } else {
                    saveOldCourse(txtCourseCode, txtCourseName, studentTable, expTable, taskTable);
                }

                courseFrame.dispose();
                new CourseExpectation(txtCourseCode.getText(), txtCourseName.getText(),
                        expectations, students, generalTasks);

            }
        });
        submit.setBounds(725, 680, 100, 25);
        courseFrame.add(submit);

        courseFrame.setVisible(true);

    }

    private void loadCourse(String selectedCourse) throws FileNotFoundException, IOException {
        BufferedReader br = new BufferedReader(new FileReader(selectedCourse + ".txt"));
        String line = br.readLine();
        String studentNumber = "";

        try {
            while (line != null) {

                if (!"".equals(line)) {
                    String valueType = line.substring(0, 2);
                    String info = line.substring(3);

                    switch (valueType) {
                        case "CC":
                            courseCode = line.substring(3);
                            break;

                        case "CN":
                            courseTitle = line.substring(3);
                            break;

                        case "CE":
                            ascii++;
                            String expParts[] = info.split("%");
                            String[] expSpecifics = expParts[2].split(",");
                            Expectation expExpectations = new Expectation(expParts[0], expParts[1], expSpecifics);
                            expectations.add(expExpectations);
                            break;

                        case "CS":
                            String sdntParts[] = info.split("%");
                            studentNumber = sdntParts[0];
                            Student sdntExpectations = new Student(sdntParts[0], sdntParts[1], sdntParts[2], new LinkedHashMap());
                            students.put(sdntParts[0], sdntExpectations);
                            break;

                        case "CT":
                            String taskParts[] = info.split("%");
                            String[] taskSpecifics = taskParts[2].split(",");
                            GeneralTask taskDesc = new GeneralTask(taskParts[0], taskParts[1], taskSpecifics);
                            generalTasks.add(taskDesc);
                            break;

                        case "SM":
                            String markParts[] = info.split("%");
                            students.get(studentNumber).marks.put(markParts[0], markParts[1]);

                            break;

                    }

                }
                line = br.readLine();

            }

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            br.close();
        }
    }

    public DefaultTableModel expectationTable(JFrame courseFrame, JPanel panel1, JPanel panel2) {

        JLabel expTitle = new JLabel(" Course Expectations");
        label(500, 165, 100, 20, "Strand:", null, courseFrame);
        label(500, 200, 100, 20, "Strand Name:", null, courseFrame);
        label(500, 235, 120, 20, "Specific Strands:", null, courseFrame);

        JTextField strand = textfield(630, 160, 200, 30, null, courseFrame, Character.toString(ascii));
        JTextField strandName = textfield(630, 195, 200, 30, null, courseFrame, null);

        for (int i = 0; i < labels.length; i++) {
            Checkbox checkbox = new Checkbox(labels[i]);
            spExp.add(checkbox);
            panel2.add(checkbox);
        }

        DefaultTableModel expModel = new DefaultTableModel();
        JTable expTable = new JTable(expModel) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        expModel.addColumn("Strand");
        expModel.addColumn("Strand Name");
        expModel.addColumn("Specific Expecations");

        expTable.getColumnModel().getColumn(0).setPreferredWidth(50);
        expTable.getColumnModel().getColumn(1).setPreferredWidth(150);
        expTable.getColumnModel().getColumn(2).setPreferredWidth(250);

        JScrollPane scrollPane = new JScrollPane(expTable);
        panel1.add(expTitle, BorderLayout.NORTH);
        panel1.add(scrollPane, BorderLayout.CENTER);

        for (int rowNum = 0; rowNum < expectations.size(); rowNum++) {
            String specificsToString = "";

            for (int i = 0; i < expectations.get(rowNum).specificExpectations.length; i++) {
                specificsToString = specificsToString + "," + expectations.get(rowNum).specificExpectations[i];
            }

            expModel.addRow(new Object[]{
                expectations.get(rowNum).strand,
                expectations.get(rowNum).strandName,
                specificsToString.substring(1)
            });
        }

        JButton addRow = new JButton(new AbstractAction("Add Row") {
            String temp = "";
            boolean checked = false;

            public void actionPerformed(ActionEvent e) {

                numOfExp++;

                for (int i = 0; i < labels.length; i++) {
                    if (spExp.get(i).getState() == true) {
                        if (checked == true) {
                            temp = temp + "," + ascii + Integer.toString(i + 1);
                        } else {
                            temp = ascii + Integer.toString(i + 1);
                            checked = true;
                        }
                    }
                }

                String nextRow = Integer.toString(expModel.getRowCount());

                expModel.addRow(new Object[]{
                    strand.getText(),
                    strandName.getText(),
                    temp});

                String[] expSpecifics = temp.split(",");
                Expectation expExpectations = new Expectation(strand.getText(), strandName.getText(), expSpecifics);
                expectations.add(expExpectations);

                if (ascii < 90) {
                    ascii++;
                }

                strand.setText(Character.toString(ascii));
                strandName.setText(null);

                for (int i = 0; i < labels.length; i++) {
                    spExp.get(i).setState(false);
                }

                temp = "";
                checked = false;
            }
        });

        addRow.setBounds(500, 270, 100, 20);
        courseFrame.add(addRow);
        courseFrame.add(panel1);
        courseFrame.add(panel2);
        return expModel;
    }

    public DefaultTableModel studentTable(JFrame courseFrame, JPanel panel3) {

        JLabel studentTitle = new JLabel(" Students");
        label(500, 335, 120, 20, "Student Number: ", null, courseFrame);
        label(500, 370, 100, 20, "First Name:", null, courseFrame);
        label(500, 405, 100, 20, "Last Name:", null, courseFrame);

        JTextField studentNum = textfield(630, 330, 200, 30, null, courseFrame, null);
        JTextField studentFirst = textfield(630, 365, 200, 30, null, courseFrame, null);
        JTextField studentLast = textfield(630, 400, 200, 30, null, courseFrame, null);

        DefaultTableModel studentModel = new DefaultTableModel();
        JTable studentTable = new JTable(studentModel) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        studentModel.addColumn("Student Number");
        studentModel.addColumn("First Name");
        studentModel.addColumn("Last Name");

        studentTable.getColumnModel().getColumn(0).setPreferredWidth(200);
        studentTable.getColumnModel().getColumn(1).setPreferredWidth(125);
        studentTable.getColumnModel().getColumn(2).setPreferredWidth(125);

        JScrollPane scrollPane = new JScrollPane(studentTable);

        panel3.add(studentTitle, BorderLayout.NORTH);
        panel3.add(scrollPane, BorderLayout.CENTER);

        for (Map.Entry item : students.entrySet()) {
            Student theStudent = (Student) item.getValue();

            studentModel.addRow(new Object[]{
                theStudent.studentNumber,
                theStudent.firstName,
                theStudent.lastName
            });
        }

        JButton addRow = new JButton(new AbstractAction("Add Row") {

            public void actionPerformed(ActionEvent e) {

                numOfStudents++;

                Student sdnt = new Student(studentNum.getText(), studentFirst.getText(), studentLast.getText(), null);
                students.put(studentNum.getText(), sdnt);

                studentModel.addRow(new Object[]{
                    studentNum.getText(),
                    studentFirst.getText(),
                    studentLast.getText()});

                studentNum.setText(null);
                studentFirst.setText(null);
                studentLast.setText(null);
            }

        });

        addRow.setBounds(500, 440, 100, 20);
        courseFrame.add(panel3);
        courseFrame.add(addRow);

        return studentModel;

    }

    public DefaultTableModel taskTable(JFrame courseFrame, JPanel panel4, JTextField code) {
        JLabel taskTitle = new JLabel(" Tasks");

        DefaultTableModel taskModel = new DefaultTableModel();
        JTable taskTable = new JTable(taskModel) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        taskModel.addColumn("Task Name");
        taskModel.addColumn("Task Type");
        taskModel.addColumn("Task Expectations");

        taskTable.getColumnModel().getColumn(0).setPreferredWidth(125);
        taskTable.getColumnModel().getColumn(1).setPreferredWidth(125);
        taskTable.getColumnModel().getColumn(2).setPreferredWidth(200);

        JScrollPane scrollPane = new JScrollPane(taskTable);

        for (int i = 0; i < generalTasks.size(); i++) {

            GeneralTask aTask = generalTasks.get(i);
            String specifics = "";

            for (int j = 0; j < aTask.taskExpectations.length; j++) {
                specifics = specifics + "," + aTask.taskExpectations[j];
            }

            String substring = specifics.substring(1);

            taskModel.addRow(new Object[]{
                aTask.taskName,
                aTask.taskType,
                substring
            });
        }

        JButton addRow = new JButton(new AbstractAction("+ Add A Task") {

            public void actionPerformed(ActionEvent e) {

                try {
                    Task task = new Task(code.getText(), taskModel, expectations, generalTasks);

                } catch (IOException ex) {
                    Logger.getLogger(CreateCourse.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        addRow.setBounds(500, 550, 130, 35);

        panel4.add(taskTitle, BorderLayout.NORTH);
        panel4.add(scrollPane, BorderLayout.CENTER);

        courseFrame.add(panel4);
        courseFrame.add(addRow);
        return taskModel;

    }

    public void saveOldCourse(JTextField code, JTextField name, DefaultTableModel studentTable, DefaultTableModel expTable, DefaultTableModel taskTable) {

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(";yyyy-MM-dd;HH-mm-ss");
        LocalDateTime now = LocalDateTime.now();
        String string = dtf.format(now);

        File oldFile = new File(code.getText() + ".txt");
        String[] filePath = oldFile.getAbsolutePath().split(code.getText());
        oldFile.delete();

        //  File renamedFile = new File(filePath[0]+string+".txt");
        //  oldFile.renameTo(renamedFile);
        File newFile = new File(code.getText() + ".txt");
        try {
            newFile.createNewFile();
        } catch (IOException ex) {
            Logger.getLogger(CreateCourse.class.getName()).log(Level.SEVERE, null, ex);
        }

        FileWriter fw = null;
        BufferedWriter bw = null;
        PrintWriter pw = null;

        try {
            fw = new FileWriter(newFile);
            bw = new BufferedWriter(fw);
            pw = new PrintWriter(bw);

            pw.println("CC " + code.getText());
            pw.println("");
            pw.println("CN " + name.getText());
            pw.println("");

            writeTableToFile("CE ", expTable, pw);
            writeTableToFile("CT ", taskTable, pw);

            //writeTableToFile("CS ", studentTable, pw);
            for (Map.Entry item : students.entrySet()) {
                pw.print("CS ");
                Student theStudent = (Student) item.getValue();
                pw.print(theStudent.studentNumber + "%");
                pw.print(theStudent.firstName + "%");
                pw.println(theStudent.lastName + "%");

                for (Map.Entry taskMarks : theStudent.marks.entrySet()) {
                    pw.print("SM ");
                    pw.print(taskMarks.getKey() + "%");
                    pw.print(taskMarks.getValue() + "%");
                }
                pw.println("");
            }

        } catch (IOException e) {
            System.out.println(e);

            System.out.println(e);
        } finally {
            try {
                if (fw != null && bw != null && pw != null) {
                    bw.close();
                    fw.close();
                    pw.close();
                }
            } catch (IOException e) {
                System.out.println(e);
            }
        }
    }

    public void saveNewCourse(JTextField code, JTextField name, DefaultTableModel studentTable, DefaultTableModel expTable, DefaultTableModel taskTable) {

        Path newCourse = Paths.get(code.getText() + ".txt");
        final Path courseList;

        if (!Files.exists(newCourse)) {
            try {
                if (!Files.exists(Paths.get("Course-list"))) {
                    courseList = Paths.get("Course-list");
                }
                FileWriter courseListWriter;

                courseListWriter = new FileWriter("Course-list.txt", true);
                courseListWriter.write("\r\n" + code.getText());
                courseListWriter.close();

            } catch (IOException ex) {
                Logger.getLogger(CreateCourse.class.getName()).log(Level.SEVERE, null, ex);
            }

            FileWriter fw = null;
            BufferedWriter bw = null;
            PrintWriter pw = null;

            try {
                fw = new FileWriter(code.getText() + ".txt");
                bw = new BufferedWriter(fw);
                pw = new PrintWriter(bw);

                pw.println("CC " + code.getText());
                pw.println("");
                pw.println("CN " + name.getText());
                pw.println("");

                writeTableToFile("CE ", expTable, pw);
                writeTableToFile("CT ", taskTable, pw);
                writeTableToFile("CS ", studentTable, pw);

            } catch (IOException e) {
                System.out.println(e);

                System.out.println(e);
            } finally {
                try {
                    if (fw != null && bw != null && pw != null) {
                        bw.close();
                        fw.close();
                        pw.close();
                    }
                } catch (IOException e) {
                    System.out.println(e);
                }
            }
        }
    }

    @Override
    public void tableChanged(TableModelEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void writeTableToFile(String s, DefaultTableModel table, PrintWriter pw) {
        for (int rowCount = 0; rowCount < table.getRowCount(); rowCount++) {
            pw.print(s);
            for (int columnCount = 0; columnCount < 3; columnCount++) {
                pw.print(table.getValueAt(rowCount, columnCount).toString() + "%");
            }
            pw.println("");
        }
        pw.println("");
    }

}