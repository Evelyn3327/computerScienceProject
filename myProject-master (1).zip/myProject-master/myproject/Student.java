
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myproject;

import java.util.LinkedHashMap;

/**
 *
 * @author luf
 */
public class Student {

    String studentNumber;
    String firstName;
    String lastName;
    LinkedHashMap<String, String> marks;

    public Student(String StudentNumber, String FirstName, String LastName, LinkedHashMap<String, String> Marks) {
        studentNumber = StudentNumber;
        firstName = FirstName;
        lastName = LastName;
        marks = Marks;
    }
}