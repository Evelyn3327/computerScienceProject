/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myproject;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.border.Border;

/**
 *
 * @author Evelyn He
 *
 */
public class MyProject extends AbstractAction {

    int titleHeight = 38;
    int titleFontSize = 25;
    int fontSize = 23;

    Color darkGreen = new Color(17, 59, 8);
    Color white = new Color(238, 238, 238);
    Color lightGreen = new Color(76, 187, 23);
    Color gray = new Color(169, 169, 169);

    Border blackline = BorderFactory.createLineBorder(Color.black);

    public JFrame Frame(int w, int h, boolean exit) {

        JFrame frame = new JFrame();
        frame.setSize(w, h);
        frame.setResizable(false);
        frame.setLocation(0, 0);
        frame.setLayout(null);
        
        if (exit) {
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        } else {
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        }
        
        return frame;
    }

    public void Title(String s, JFrame j, int fnt, int add) {

        JPanel titlePanel = new JPanel();
        titlePanel.setBounds(0, 0, j.getWidth(), titleHeight + add);
        titlePanel.setLayout(null);
        titlePanel.setBackground(darkGreen);

        JLabel title = new JLabel(s);
        title.setBounds(0, 0, j.getWidth() - 35, titleHeight + add);
        title.setForeground(white);
        title.setFont(title.getFont().deriveFont((float) (fnt)));
        titlePanel.add(title);

        ImageIcon scaled = new ImageIcon("home-button.png");
        Image image = scaled.getImage();
        Image unscaled = image.getScaledInstance(30, 30, java.awt.Image.SCALE_SMOOTH);
        scaled = new ImageIcon(unscaled);

        JButton home = new JButton(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                j.dispose();
                Homescreen h = new Homescreen();
            }
        });

        home.setIcon(scaled);

        home.setBounds(titlePanel.getWidth() - 50, 5, 30, 30);
        home.setBackground(darkGreen);
        titlePanel.add(home);

        j.add(titlePanel);
    }

    public void label(int x, int y, int w, int h, String s, JPanel p, JFrame f) {

        JLabel l = new JLabel(s);
        l.setBounds(x, y, w, h);
        Font newLabelFont = new Font(l.getFont().getName(), Font.PLAIN, 12);
        l.setFont(newLabelFont);
        if (p != null) {
            p.add(l);
        } else {
            f.add(l);
        }
    }

    public JTextField textfield(int x, int y, int w, int h, JPanel p, JFrame f, String val) {

        JTextField t = new JTextField(val);
        t.setBounds(x, y, w, h);
        if (p != null) {
            p.add(t);
        } else {
            f.add(t);
        }
        return t;
    }

    public static void main(String args[]) {

        try {
            for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        new Homescreen();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println(e);
    }
}