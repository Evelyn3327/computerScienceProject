/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myproject;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 *
 * @author earl
 */
public class EvidenceRecord extends MyProject {

    JFrame evidenceFrame;
    JPanel overallContainer;

    String[] avaliableGrades = {" ", "INC", "-", "R", "+", "-", "1", "+", "-", "2", "+", "-", "3", "+",
        "3+/4-", "4-", "4-/4", "4", "4/4+", "4+", "4++"};

    public EvidenceRecord(String s, String courseCode, String courseName,
            ArrayList<Expectation> expectations, LinkedHashMap<String, Student> students,
            ArrayList<GeneralTask> tasks) {

        evidenceFrame = Frame(1000, 700, false);
        super.Title(" Evidence Record - " + courseCode, evidenceFrame, super.titleFontSize, 0);

        overallContainer = new JPanel(new BorderLayout());
        overallContainer.setBounds(10, super.titleHeight + 20, 975, 700 - (super.titleHeight + 100));
        overallContainer.setBackground(darkGreen);

        makeTable(s, courseCode, expectations, students, tasks);

        System.out.println(s);

        evidenceFrame.add(overallContainer);
        evidenceFrame.setVisible(true);
    }

    public void makeTable(String s, String courseCode,
            ArrayList<Expectation> expectations, LinkedHashMap<String, Student> students,
            ArrayList<GeneralTask> tasks) {

        JPanel overallGrades = new JPanel(new GridLayout(0, avaliableGrades.length));
                overallGrades.setBackground(Color.BLACK);
        overallGrades.setMinimumSize(new Dimension(overallContainer.getWidth(),30));

        for (int i = 0; i < avaliableGrades.length; i++) {
            JLabel thisGrade = new JLabel(avaliableGrades[i],SwingConstants.CENTER);
            thisGrade.setBackground(gray);
            String txt = thisGrade.getText();
            
            if ("-".equals(txt)||"INC".equals(txt)||"3+/4-".equals(txt)) {
                thisGrade.setBorder(BorderFactory.createMatteBorder(1, 2, 1, 0, Color.BLACK));
            } else{
                thisGrade.setBorder(BorderFactory.createMatteBorder(1,1,1,0, Color.BLACK));
            }
            thisGrade.setOpaque(true);
            overallGrades.add(thisGrade);

        }

        overallContainer.add(overallGrades, BorderLayout.PAGE_START);

    }

}
