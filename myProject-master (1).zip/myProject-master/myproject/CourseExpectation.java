/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myproject;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Evelyn He
 */
public class CourseExpectation extends MyProject {

    JPanel studentTblHolder;
    JPanel marksTblHolder;

    DefaultTableModel studentModel = new DefaultTableModel();
    JTable studentTable;
    JScrollPane studentScrollPane;

    DefaultTableModel marksModel;
    JTable marksTable = new JTable();
    JScrollPane marksScrollPane;
    String courseClicked;

    Font labelFont = new Font("Nimbus", Font.BOLD, 14);

    int numColumns = 0;
    int numRows = 0;

    JFrame expectationFrame = super.Frame(600, 550, true);

    public CourseExpectation(String courseCode, String courseName,
            ArrayList<Expectation> expectations, LinkedHashMap<String, Student> students,
            ArrayList<GeneralTask> tasks) {

        super.Title(" Evaluation And Assesment - " + courseCode, expectationFrame, super.titleFontSize, 0);

        studentTblHolder = new JPanel(new BorderLayout());
        studentTblHolder.setBounds(10, 100, 350, 400);
        studentTblHolder.setBackground(Color.BLACK);

        addDropDownMenu(courseCode, courseName, expectations, students, tasks);

        JButton save = new JButton("save");

        save.addActionListener((ActionEvent e) -> {
            try {
                saveButtonPressed(courseCode, courseName, expectations,
                        students, tasks, marksModel, courseClicked);
            } catch (IOException ex) {
                Logger.getLogger(CourseExpectation.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        save.setBounds(500, 500, 100, 20);

        expectationFrame.add(save);
        expectationFrame.setVisible(true);
    }

    public void saveButtonPressed(String courseCode, String courseName,
            ArrayList<Expectation> expectations, LinkedHashMap<String, Student> students,
            ArrayList<GeneralTask> tasks, DefaultTableModel taskModel, String task) throws IOException {

        int row = 0;
        String specificMarks = "";

        for (String key : students.keySet()) {
            for (int column = 0; column < numColumns; column++) {
                specificMarks = specificMarks + "," + (String) taskModel.getValueAt(row, column);
            }

            specificMarks = specificMarks.substring(1);
            Student theStudent = students.get(key);
            theStudent.marks.put(task, specificMarks);

            specificMarks = "";
            row++;
        }

        File oldFile = new File(courseCode + ".txt");
        String[] filePath = oldFile.getAbsolutePath().split(courseCode);
        oldFile.delete();

        //  File renamedFile = new File(filePath[0]+string+".txt");
        //  oldFile.renameTo(renamedFile);
        File newFile = new File(courseCode + ".txt");

        FileWriter fw = null;
        BufferedWriter bw = null;
        PrintWriter pw = null;
        try {
            fw = new FileWriter(newFile);
            bw = new BufferedWriter(fw);
            pw = new PrintWriter(bw);

            pw.println("CC " + courseCode);
            pw.println("");
            pw.println("CN " + courseName);
            pw.println("");

            for (int numExp = 0; numExp < expectations.size(); numExp++) {
                pw.print("CE ");
                pw.print(expectations.get(numExp).strand + "%");
                pw.print(expectations.get(numExp).strandName + "%");

                int length = expectations.get(numExp).specificExpectations.length;

                String s = "";
                for (int numSpecific = 0; numSpecific < length; numSpecific++) {
                    s = s + "," + expectations.get(numExp).specificExpectations[numSpecific];
                }
                pw.println(s.substring(1) + "%");
            }
            pw.println("");

            for (int numTask = 0; numTask < tasks.size(); numTask++) {
                pw.print("CT ");
                pw.print(tasks.get(numTask).taskName + "%");
                pw.print(tasks.get(numTask).taskType + "%");

                int length = tasks.get(numTask).taskExpectations.length;
                String s = "";
                for (int numSpecific = 0; numSpecific < length; numSpecific++) {
                    s = s + "," + tasks.get(numTask).taskExpectations[numSpecific];
                }
                pw.println(s.substring(1) + "%");
            }
            pw.println("");

            for (Map.Entry item : students.entrySet()) {
                pw.print("CS ");
                Student theStudent = (Student) item.getValue();
                pw.print(theStudent.studentNumber + "%");
                pw.print(theStudent.firstName + "%");
                pw.println(theStudent.lastName + "%");

                for (Map.Entry taskMarks : theStudent.marks.entrySet()) {
                    pw.print("SM ");
                    pw.print(taskMarks.getKey() + "%");
                    pw.println(taskMarks.getValue() + "%");
                }
            }

        } catch (IOException e) {
            System.out.println(e);

            System.out.println(e);
        } finally {
            try {
                if (fw != null && bw != null && pw != null) {
                    bw.close();
                    fw.close();
                    pw.close();
                }
            } catch (IOException e) {
                System.out.println(e);
            }
        }

    }

    private void addDropDownMenu(String courseCode, String courseName,
            ArrayList<Expectation> expectations, LinkedHashMap<String, Student> students,
            ArrayList<GeneralTask> tasks) {

        ArrayList<String> addTask = new ArrayList();

        for (int i = 0; i < tasks.size(); i++) {
            addTask.add(i, tasks.get(i).taskName);
        }

        JComboBox taskList = new JComboBox();
        DefaultComboBoxModel dml = new DefaultComboBoxModel();
        for (int i = 0; i < addTask.size(); i++) {
            dml.addElement(addTask.get(i));
        }
        taskList.setModel(dml);
        taskList.setSelectedIndex(0);
        courseClicked = taskList.getItemAt(0).toString();

        numRows = studentTable(courseCode, courseName, expectations, students, tasks);
        DefaultTableModel marksModel = marksTable(students, tasks, 0, numRows, courseClicked);

        studentTable.setSelectionModel(marksTable.getSelectionModel());
        studentScrollPane.getVerticalScrollBar().setModel(marksScrollPane.getVerticalScrollBar().getModel());
        taskList.setBounds(10, 48, 150, 40);
        expectationFrame.add(taskList);

        taskList.addActionListener((ActionEvent e) -> {
            JComboBox cb = (JComboBox) e.getSource();
            courseClicked = (String) cb.getSelectedItem();

            for (int i = 0; i < taskList.getItemCount(); i++) {
                if (taskList.getItemAt(i).toString().equals(courseClicked)) {
                    newMarksTable(students, tasks, i, numRows, marksModel, courseClicked);
                }
            }
        });
    }

    public int studentTable(String courseCode, String courseName,
            ArrayList<Expectation> expectations, LinkedHashMap<String, Student> students,
            ArrayList<GeneralTask> tasks) {

        JLabel studentTitle = new JLabel(" Student Information");
        studentTitle.setForeground(Color.WHITE);
        studentTitle.setFont(labelFont);
        studentTitle.setSize(350, 100);
        studentTitle.setBorder(blackline);

        studentModel.addColumn("Student Number");
        studentModel.addColumn("First Name");
        studentModel.addColumn("Last Name");

        studentTable = new JTable(studentModel) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        studentTable.getColumnModel().getColumn(0).setWidth(200);
        studentTable.getColumnModel().getColumn(1).setWidth(125);
        studentTable.getColumnModel().getColumn(2).setWidth(125);

        studentScrollPane = new JScrollPane(studentTable);
        studentScrollPane.setPreferredSize(new Dimension(350, 200));
        studentScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);

        studentTblHolder.add(studentTitle, BorderLayout.NORTH);
        studentTblHolder.add(studentScrollPane, BorderLayout.WEST);

        ArrayList<Student> list = new ArrayList<>(students.values());

        for (int i = 0; i < students.size(); i++) {
            studentModel.addRow(new Object[]{
                list.get(i).studentNumber,
                list.get(i).firstName,
                list.get(i).lastName
            });
        }
        studentTable.setRowHeight(20);
        studentTable.setShowVerticalLines(true);
        studentTable.setShowHorizontalLines(true);

        studentTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {

                    int row = studentTable.getSelectedRow();
                    int column = studentTable.getSelectedColumn();

                    if (column == 0) {
                        String studentNum = list.get(row).studentNumber;

                        new EvidenceRecord(studentNum,courseCode, courseName, 
                                expectations, students, tasks);
                    }
                }
            }

        });

        expectationFrame.add(studentTblHolder);

        return students.size();
    }

    public DefaultTableModel marksTable(LinkedHashMap<String, Student> students,
            ArrayList<GeneralTask> tasks, int taskSelected, int numRows, String task) {

        marksModel = new DefaultTableModel();
        marksTable.setModel(marksModel);

        JLabel marksTitle = new JLabel("Marks");
        marksTitle.setForeground(Color.WHITE);
        marksTitle.setSize(tasks.size() * 25, 100);
        marksTitle.setFont(labelFont);
        marksTitle.setBorder(blackline);

        String[] allExpectations = tasks.get(taskSelected).taskExpectations;

        for (int i = 0; i < allExpectations.length; i++) {
            marksModel.addColumn(allExpectations[i]);
            numColumns++;
        }

        for (int i = 0; i < allExpectations.length; i++) {
            marksTable.getColumnModel().getColumn(i).setWidth(25);
        }
        marksScrollPane = new JScrollPane(marksTable);
        marksScrollPane.setPreferredSize(new Dimension((allExpectations.length) * 35 + 20, 200));
        marksScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        marksTblHolder = new JPanel(new BorderLayout());
        marksTblHolder.setBounds(360, 100, allExpectations.length * 35 + 20, 400);
        marksTblHolder.setBackground(Color.BLACK);

        marksTblHolder.add(marksTitle, BorderLayout.NORTH);
        marksTblHolder.add(marksScrollPane, BorderLayout.WEST);
        marksTblHolder.setBackground(Color.BLACK);

        students.keySet().forEach((key) -> {
            String[] row = new String[numColumns];
            String allMarks = students.get(key).marks.get(task);

            if (allMarks != null) {
                String[] specificMarks = allMarks.split(",");

                for (int i = 0; i < row.length; i++) {
                    row[i] = specificMarks[i];
                }

                marksModel.addRow(row);
            } else {
                marksModel.addRow(new String[]{});
            }
        });

        marksTable.setRowHeight(20);
        marksTable.setShowVerticalLines(true);
        marksTable.setShowHorizontalLines(true);

        expectationFrame.add(marksTblHolder);

        return marksModel;
    }

    public DefaultTableModel newMarksTable(LinkedHashMap<String, Student> students,
            ArrayList<GeneralTask> tasks, int taskSelected, int numRows,
            DefaultTableModel marksModel, String task) {

        marksTblHolder.remove(marksScrollPane);
        numColumns = 0;
        marksModel.setColumnCount(0);
        marksModel.setRowCount(0);
        marksModel.fireTableDataChanged();
        marksModel.fireTableStructureChanged();

        JLabel marksTitle = new JLabel("Marks");
        marksTitle.setSize(tasks.size() * 25, 100);
        marksTitle.setFont(labelFont);
        marksTitle.setBorder(blackline);

        String[] allExpectations = tasks.get(taskSelected).taskExpectations;

        for (int i = 0; i < allExpectations.length; i++) {
            numColumns++;
            marksModel.addColumn(allExpectations[i]);
        }

        for (int i = 0; i < allExpectations.length; i++) {
            marksTable.getColumnModel().getColumn(i).setWidth(25);
        }

        marksTable.revalidate();

        marksScrollPane = new JScrollPane(marksTable);
        marksScrollPane.setPreferredSize(new Dimension(allExpectations.length * 35 + 20, 200));
        marksScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        studentScrollPane.getVerticalScrollBar().setModel(marksScrollPane.getVerticalScrollBar().getModel());

        marksTblHolder.setBounds(360, 100, allExpectations.length * 35 + 20, 400);
        marksTblHolder.setBackground(Color.BLACK);
        marksTblHolder.revalidate();

        marksTblHolder.add(marksTitle, BorderLayout.NORTH);
        marksTblHolder.add(marksScrollPane, BorderLayout.WEST);

        students.keySet().forEach((key) -> {
            String[] row = new String[numColumns];
            String allMarks = students.get(key).marks.get(task);

            if (allMarks != null) {
                String[] specificMarks = allMarks.split(",");

                for (int i = 0; i < row.length; i++) {
                    row[i] = specificMarks[i];
                }

                marksModel.addRow(row);
            } else {
                marksModel.addRow(new String[]{});
            }
        });

//        for (int i = 0; i < numRows; i++) {
//            marksModel.addRow(new Object[]{});
//
//        }
        marksTable.setRowHeight(20);
        marksTable.setShowVerticalLines(true);
        marksTable.setShowHorizontalLines(true);

        marksModel.fireTableRowsUpdated(0, numRows - 1);
        marksModel.fireTableStructureChanged();

        return marksModel;

    }
}
