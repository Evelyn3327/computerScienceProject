/*
 * The class creates an Expectation object, which contains an overall expectation,
 * a name, and an array of specific expectations.
 */
package myproject;

/**
 *
 * @author Evelyn He
 */
 public class Expectation {

        String strand;
        String strandName;
        String[] specificExpectations;

        public Expectation(String Strand, String StrandName, String[] StrandExpectations) {
            strand = Strand;
            strandName = StrandName;
            specificExpectations = StrandExpectations;
        }
}