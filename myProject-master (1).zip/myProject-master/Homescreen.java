/* This is the code for the homescreen of the project. It includes 2 buttons:
 * one to find a previously created course, and one to find a newly created
 * course.
 */
package myproject;

import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;

/**
 * @author Evelyn He
 */
public class Homescreen extends MyProject {

    private final JButton FIND_COURSE;
    private final JButton CREATE_COURSE;

    public Homescreen() {

        JFrame homescreenFrame = frame(0,0,455, 256, 3);
        title(" Marking Organizor", homescreenFrame, super.titleFontSize, 40, false);

        //Creates "Find Course" button, which calls the FindCourse class on action event
        FIND_COURSE = new JButton(new AbstractAction("Find A Course") {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new FindCourse();
                } catch (IOException ex) {
                    Logger.getLogger(Homescreen.class.getName()).
                            log(Level.SEVERE, null, ex);
                }
                homescreenFrame.dispose();
            }
        });

        FIND_COURSE.setBounds(152, 102, 150, 21);

        //Creates "Create Course" button, which calls the CreateCourse class on action event
        CREATE_COURSE = new JButton(new AbstractAction("Create A Course") {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new CreateCourse(null);
                } catch (IOException ex) {
                    Logger.getLogger(Homescreen.class.getName()).log(Level.SEVERE, null, ex);
                }
                homescreenFrame.dispose();
            }
        });
        CREATE_COURSE.setBounds(152, 128, 150, 21);

        homescreenFrame.add(FIND_COURSE);
        homescreenFrame.add(CREATE_COURSE);
        homescreenFrame.setVisible(true);
    }//end of constructor
}//End Homescreen class
