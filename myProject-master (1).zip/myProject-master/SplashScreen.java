/*
 * The class creates a loading screen with a progress bar which pops up when
 * the user runs the program.
 * 
 */
package myproject;

import java.awt.BorderLayout;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JWindow;

/**
 *
 * @author Evelyn He
 */
public final class SplashScreen extends MyProject {

    public SplashScreen() {
        JWindow window = new JWindow();
        window.setBounds(0, 0, 455, 256);

        JPanel container = new JPanel(new BorderLayout());

        ImageIcon background = new ImageIcon("background screen.png");
        JLabel backgroundPnl = new JLabel(background);
        backgroundPnl.setOpaque(true);

        JProgressBar pb = new JProgressBar();
        pb.setString("Loading...");
        pb.setForeground(white);
        pb.setStringPainted(true);

        container.add(backgroundPnl, BorderLayout.NORTH);
        container.add(pb, BorderLayout.SOUTH);
        container.setBackground(lightGreen);

        window.getContentPane().add(container);
        window.setVisible(true);

        increaseBar(pb);

        window.setVisible(false);
        new Homescreen();

    }//end of constructor

    //Randomly increases the progress of the JProgressBar
    public void increaseBar(JProgressBar pb) {
        int low = 0;
        int high = 2;

        int progress = 0;
        pb.setValue(progress);
        
        while (progress < 100) {
            
            Random r = new Random();
            int result = r.nextInt(high - low) + low;
            try {
                Thread.sleep(15);
            } catch (InterruptedException ignore) {
                System.out.println(ignore);
            }
            
            progress = progress+result;
            pb.setValue(Math.min(progress, 100));
        }
    }//end of increaseBar()

}//end of SplashScreen class
