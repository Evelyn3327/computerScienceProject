
/*
 * The class creates a Student object, which has a student number, first name,
 * and last name.
 */
package myproject;

import java.util.LinkedHashMap;

/**
 *
 * @author Evelyn He
 */
public class Student {

    String studentNumber;
    String firstName;
    String lastName;
    LinkedHashMap<String, String> marks;

    public Student(String StudentNumber, String FirstName, String LastName, LinkedHashMap<String, String> Marks) {
        studentNumber = StudentNumber;
        firstName = FirstName;
        lastName = LastName;
        marks = Marks;
    }
}