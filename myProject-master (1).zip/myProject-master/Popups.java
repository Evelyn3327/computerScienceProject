/*
 * This class contains methods for the three popups that could appear in the UI.
 * The first prompts the user to fill in empty text fields.
 * The second confirms that the user wants to exit without saving.
 * The third confirms a sucessful save.
 */
package myproject;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * @since 10/23/2020
 * @author Evelyn He
 */
public class Popups extends MyProject {

    JFrame frame = frame(700,300,300, 135, 2);
    JPanel overallPnl = new JPanel(new BorderLayout());

    //Popup for if textfields which contain essential information are left empty
    public void fieldLeftEmpty() {

        frame.setLayout(new BorderLayout());

        overallPnl.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel txtHolder = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel text = new JLabel(" Missing or empty fields");

        ImageIcon scaled = new ImageIcon("error-icon.png");
        Image image = scaled.getImage();
        Image unscaled = image.getScaledInstance(20, 20, java.awt.Image.SCALE_SMOOTH);
        scaled = new ImageIcon(unscaled);
        JLabel warningIcon = new JLabel(scaled);

        txtHolder.add(warningIcon);
        txtHolder.add(text);

        JPanel btnHolder = new JPanel(new BorderLayout());

        JButton okButton = new JButton(new AbstractAction("Ok") {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });
        okButton.setPreferredSize(new Dimension(50, 25));
        btnHolder.add(okButton, BorderLayout.EAST);

        overallPnl.add(txtHolder, BorderLayout.NORTH);
        overallPnl.add(btnHolder, BorderLayout.SOUTH);

        frame.add(overallPnl);
        frame.setVisible(true);

    }//end of fieldLeftEmpty()

    //Confirms that user wants to exit without saving changes
    public void confirmExit() {

        frame.setSize(400, 125);
        frame.revalidate();
        frame.setLayout(new BorderLayout());

        overallPnl.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel txtHolder = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel text = new JLabel(" Exit without saving? Some changes may be lost.");

        ImageIcon scaled = new ImageIcon("warning-icon.png");
        Image image = scaled.getImage();
        Image unscaled = image.getScaledInstance(20, 20, java.awt.Image.SCALE_SMOOTH);
        scaled = new ImageIcon(unscaled);
        JLabel warningIcon = new JLabel(scaled);

        txtHolder.add(warningIcon);
        txtHolder.add(text);

        JPanel btnHolder = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        JButton cancel = new JButton(new AbstractAction("Yes") {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        JButton exitWithoutSave = new JButton(new AbstractAction("No") {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }

        });

        btnHolder.add(cancel);
        btnHolder.add(exitWithoutSave);

        overallPnl.add(txtHolder, BorderLayout.NORTH);
        overallPnl.add(btnHolder, BorderLayout.SOUTH);

        frame.add(overallPnl);
        frame.setVisible(true);

    }//end of confirmExit();

    //Informs user that changes have been saved sucessfully
    public void sucessfulSave() {
        frame.setLayout(new BorderLayout());

        overallPnl.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel text = new JLabel("Changes have been saved sucessfully.");
        JPanel btnPanel = new JPanel(new BorderLayout());

        JButton okButton = new JButton(new AbstractAction("Ok") {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }

        });
        okButton.setMaximumSize(new Dimension(30, 15));
        btnPanel.add(okButton, BorderLayout.EAST);

        overallPnl.add(text, BorderLayout.NORTH);
        overallPnl.add(btnPanel, BorderLayout.PAGE_END);

        frame.add(overallPnl, BorderLayout.CENTER);
        frame.setVisible(true);

    }//end of sucessfulSave()

    public void deleted(JFrame courseFrame) {
        frame.setLayout(new BorderLayout());

        overallPnl.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel text = new JLabel("Course has been deleted");

        JButton okButton = new JButton(new AbstractAction("Ok") {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                courseFrame.dispose();
                try {
                    new FindCourse();
                } catch (IOException ex) {
                    Logger.getLogger(Popups.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        okButton.setMaximumSize(new Dimension(30,15));
        
        overallPnl.add(text,BorderLayout.NORTH);
        overallPnl.add(okButton, BorderLayout.PAGE_END);
        
        frame.add(overallPnl);
        frame.setVisible(true);

    }

}
