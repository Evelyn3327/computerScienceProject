/*
 * The class creates a Task object, which contains a task name, task type, and 
 * expectations
 */
package myproject;

/**
 *
 * @author luf
 */
public class GeneralTask {
    String taskName;
    String taskType;
    String[] taskExpectations;
    
    public GeneralTask(String TaskName, String TaskType, String[] TaskExpectations){
        taskName = TaskName;
        taskType = TaskType;
        taskExpectations = TaskExpectations;
    }
    
}