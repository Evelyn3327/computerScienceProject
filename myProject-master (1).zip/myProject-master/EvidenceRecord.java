/*
 * This class creates a dynamically evidence record which contains a student's 
 * marks, as well as a legend of all tasks that the user has previously created.
 */
package myproject;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

/**
 * @author Evelyn He
 */
public final class EvidenceRecord extends MyProject {

    JFrame evidenceFrame;
    JPanel evidenceContainer;
    JPanel legendContainer;

    String[] avaliableGrades = {" ", "INC", "-", "R", "+", "-", "1", "+", "-", "2", "+", "-", "3", "+",
        "3+/4-", "4-", "4-/4", "4", "4/4+", "4+", "4++"};

    String[] gradeSelection = {" ", "INC", "R-", "R", "R+", "1-", "1", "1+", "2-", "2", "2+", "3-", "3", "3+",
        "3+/4-", "4-", "4-/4", "4", "4/4+", "4+", "4++"};

    public EvidenceRecord(String theStudent, String courseCode, String courseName,
            ArrayList<Expectation> expectations, LinkedHashMap<String, Student> students,
            ArrayList<GeneralTask> tasks) {

        evidenceFrame = frame(200, 200, 1160, 700, 2); //width=1000
        super.title(" Evidence Record - " + courseCode, evidenceFrame, super.titleFontSize, 0, false);

        //Header of the evidence record
        String studentInfo = " " + theStudent + ": " + students.get(theStudent).firstName + " " + students.get(theStudent).lastName;
        JLabel studentLabel = new JLabel(studentInfo);
        studentLabel.setBounds(12, super.titleHeight + 20, 963, 20);
        studentLabel.setFont(new Font("Nimbus", Font.BOLD, 18));

        //Overall JPanel of evidence record
        evidenceContainer = new JPanel(new BorderLayout());
        evidenceContainer.setBounds(10, super.titleHeight + 50, 945, 540);
        evidenceContainer.setBackground(darkGreen);
        JScrollPane evidenceScrollPane = new JScrollPane(evidenceContainer);
        evidenceScrollPane.setBounds(10, super.titleHeight + 50, 968, 540);

        //Overall JPanel of legend
        legendContainer = new JPanel(new GridLayout(tasks.size(), 0));
        legendContainer.setBounds(980, super.titleHeight + 52, 150, tasks.size() * 30);
        legendContainer.setBackground(Color.LIGHT_GRAY);
        legendContainer.setBorder(blackline);

        makeTable(theStudent, courseCode, expectations, students, tasks);
        makeLegend(tasks);

        evidenceFrame.add(studentLabel);
        evidenceFrame.add(evidenceScrollPane);
        evidenceFrame.add(legendContainer);
        evidenceFrame.setVisible(true);
    }

    public void makeTable(String theStudent, String courseCode,
            ArrayList<Expectation> expectations, LinkedHashMap<String, Student> students,
            ArrayList<GeneralTask> tasks) { //Creates evidence record

        int numRows = 1;

        GridBagLayout gbl = new GridBagLayout();
        evidenceContainer.setLayout(gbl);

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(0, 0, 0, 0);
        c.anchor = GridBagConstraints.NORTHWEST;

        Font titleFont = new Font("Nimbus", Font.BOLD, 13);
        Font f = new Font("Nimbus", Font.BOLD, 11);

        /*Creating a row of headers for evidence record (ex. INC,R-,R, etc.) and
        adding it to the overall container*/
        JPanel generalMarksHolder = addPanel(0, avaliableGrades.length, 945, 30, false);
        for (String avaliableGrade : avaliableGrades) {
            JLabel generalMarks = new JLabel(avaliableGrade, SwingConstants.CENTER);
            generalMarks.setMaximumSize(new Dimension(45, 30));

            if (avaliableGrade.equals("-") || avaliableGrade.equals("3+/4-") || avaliableGrade.equals("INC")) {
                generalMarks.setBorder(BorderFactory.createMatteBorder(0, 1, 0, 0, Color.BLACK));
            }
            generalMarks.setFont(titleFont);
            generalMarksHolder.setBackground(gray);
            generalMarksHolder.add(generalMarks);
        }
        addObj(generalMarksHolder, gbl, c, 1, 0, 1, 1);

        //For loop which creates JLabels for the overall expectations of the course.
        for (int i = 0; i < expectations.size(); i++) {
            String expectationName = expectations.get(i).strandName;
            JLabel nameLabel = addLabel(" " + expectationName, 945, 20, f, false, Color.DARK_GRAY, Color.LIGHT_GRAY);
            addObj(nameLabel, gbl, c, 1, numRows, 1, 1);
            numRows++;

            //Calls readData for every specific expectation of an overall expectation
            for (int j = 0; j < expectations.get(i).specificExpectations.length; j++) {
                readData(theStudent, expectations.get(i).specificExpectations[j], tasks, students, c, gbl, numRows);
                numRows++;
            }
        }
    }//end of makeTable() 

    public void makeLegend(ArrayList<GeneralTask> tasks) { //Creates legend

        JPanel[] legendComponents = new JPanel[tasks.size()];

        for (int i = 0; i < legendComponents.length; i++) {

            legendComponents[i] = new JPanel();
            legendComponents[i].setLayout(new FlowLayout(FlowLayout.LEFT));

            JLabel taskIconLbl = new JLabel();
            taskIconLbl.setHorizontalAlignment(SwingConstants.CENTER);
            String typeOfTask = tasks.get(i).taskType.substring(0, 1);
            
            assignColor(taskIconLbl, typeOfTask);
            taskIconLbl.setText(tasks.get(i).taskType);
            taskIconLbl.setHorizontalTextPosition(JLabel.CENTER);
            
            JLabel taskNameLbl = new JLabel();
            taskNameLbl.setText(tasks.get(i).taskName);

            legendComponents[i].add(taskIconLbl);
            legendComponents[i].add(taskNameLbl);
            legendComponents[i].setBackground(Color.LIGHT_GRAY);

            legendContainer.add(legendComponents[i]);
        }
    }//end of makeLegend() 

    public void readData(String theStudent, String theExpectation,
            ArrayList<GeneralTask> tasks, LinkedHashMap<String, Student> students,
            GridBagConstraints c, GridBagLayout gbl, int numRows) { //gets student's marks for a specific expectation

        String key = "";
        int valAt = -1;
        int repetitions = 0;
        int highestRepNum = 0;

        ArrayList<String> grades = new ArrayList();
        ArrayList<String> taskOfGrades = new ArrayList();

        /* Goes through all created tasks to see if one of its expectations matches
         * the specific expectation which has been passed in. It then gets the 
         * student's mark(s) for that expectation
         */
        for (int taskNum = 0; taskNum < tasks.size(); taskNum++) {
            int taskExpNum = tasks.get(taskNum).taskExpectations.length;

            for (int expNum = 0; expNum < taskExpNum; expNum++) {

                if (tasks.get(taskNum).taskExpectations[expNum].equals(theExpectation)) {
                    key = tasks.get(taskNum).taskType;
                    valAt = expNum;

                    if (valAt != -1) {
                        String markString = students.get(theStudent).marks.get(key);

                        if (markString != null) {
                            String[] theMark = markString.split(",");
                            grades.add(theMark[valAt]);
                            taskOfGrades.add(key);

                            int length = grades.size();

                            for (int i = 0; i < length; i++) {
                                if (theMark[valAt].equals(grades.get(i))) {
                                    repetitions++;
                                }
                                if (repetitions > highestRepNum) {
                                    highestRepNum = repetitions;
                                }
                            }
                            repetitions = 0;
                        }
                    }
                    valAt = -1;
                }
            }
        }

        if (highestRepNum == 0) {
            highestRepNum = 1;
        }

        addSpecificExp(highestRepNum, grades, taskOfGrades, theExpectation, gbl, c, numRows);
    }//end of readData()

    public void addSpecificExp(int highestRepNum, ArrayList<String> grades,
            ArrayList<String> taskOfGrades, String theExpectation,
            GridBagLayout gbl, GridBagConstraints c, int numRows) { //Creates dynamically sized panels which are added to the evidence record.

        JPanel p = addPanel(highestRepNum, 21, 945, 25 * highestRepNum, false);
        boolean hasLabeled = false;

        //Creates JLabel array for specific expectation
        JLabel[][] l = new JLabel[21][highestRepNum];

        for (int row = 0; row < highestRepNum; row++) {
            for (int col = 0; col < 21; col++) {
                l[col][row] = new JLabel();
                l[col][row].setHorizontalAlignment(SwingConstants.CENTER);
                l[col][row].setPreferredSize(new Dimension(45, 25));
                l[col][row].setOpaque(true);
                p.add(l[col][row]);
            }
        }

        for (int col = 0; col < 21; col++) {
            for (int row = 0; row < highestRepNum; row++) {

                if (col == 0 && hasLabeled == false) {
                    l[col][row].setFont(new Font("Nimbus", Font.BOLD, 11));
                    l[col][row].setText(theExpectation);
                    l[col][row].setBackground(gray);
                    hasLabeled = true;
                } else if (col == 0) {
                    l[col][row].setBackground(gray);
                } else {

                    //If column header matches the student's mark, the cell's label is replaced.
                    for (int readGrades = 0; readGrades < grades.size(); readGrades++) {
                        if (grades.get(readGrades).equals(gradeSelection[col])) {

                            assignColor(l[col][row], taskOfGrades.get(readGrades));
                            l[col][row].setText(taskOfGrades.get(readGrades));
                            l[col][row].setHorizontalTextPosition(JLabel.CENTER);

                            grades.set(readGrades, "");
                            taskOfGrades.set(readGrades, "");

                            break;
                        }
                    }
                    l[col][row].setBackground(Color.LIGHT_GRAY);
                }

                if (col == 1 || col == 2 || col == 5 || col == 8 || col == 11 || col == 14) {
                    l[col][row].setBorder(BorderFactory.createMatteBorder(0, 1, 0, 0, Color.DARK_GRAY));
                }

                if (row == 0) {
                    l[col][row].setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, Color.DARK_GRAY));
                    if (col == 1 || col == 2 || col == 5 || col == 8 || col == 11 || col == 14) {
                        l[col][row].setBorder(BorderFactory.createMatteBorder(1, 1, 0, 0, Color.DARK_GRAY));
                    }
                }

            }

        }
        addObj(p, gbl, c, 1, numRows, 1, 1);
    }//end of addSpecificExp()

    public void assignColor(JLabel l, String s) {//adds icons to JLabel marks
        String typeOfTask = s.substring(0, 1);

        switch (typeOfTask) {
            case "T":
                ImageIcon tIcon = new ImageIcon("Blue.png");
                Image tImage = tIcon.getImage();
                Image tTemp = tImage.getScaledInstance(25, 25, java.awt.Image.SCALE_SMOOTH);
                tIcon = new ImageIcon(tTemp);
                l.setIcon(tIcon);
                break;

            case "A":
                ImageIcon aIcon = new ImageIcon("Red.png");
                Image aImage = aIcon.getImage();
                Image aTemp = aImage.getScaledInstance(25, 25, java.awt.Image.SCALE_SMOOTH);
                aIcon = new ImageIcon(aTemp);
                l.setIcon(aIcon);
                break;

            case "Q":
                ImageIcon qIcon = new ImageIcon("Green.png");
                Image qImage = qIcon.getImage();
                Image qTemp = qImage.getScaledInstance(25, 25, java.awt.Image.SCALE_SMOOTH);
                qIcon = new ImageIcon(qTemp);
                l.setIcon(qIcon);
                break;

            case "S":
                ImageIcon sIcon = new ImageIcon("Magenta.png");
                Image sImage = sIcon.getImage();
                Image sTemp = sImage.getScaledInstance(25, 25, java.awt.Image.SCALE_SMOOTH);
                sIcon = new ImageIcon(sTemp);
                l.setIcon(sIcon);
                break;

            default:
                break;
        }
    }

    public JPanel addPanel(int row, int col, int w, int h, Boolean hasBorder) {
        JPanel p = new JPanel(new GridLayout(row, col));
        p.setBackground(Color.gray);
        p.setPreferredSize(new Dimension(w, h));

        if (hasBorder) {
            p.setBorder(blackline);
        }

        return p;
    }//end of addPanel()

    public JLabel addLabel(String s, int w, int h, Font f, boolean hasBorder, Color back, Color fore) {

        JLabel l = new JLabel(s);

        l.setPreferredSize(new Dimension(w, h));
        l.setFont(f);
        l.setBackground(back);
        l.setForeground(fore);
        l.setOpaque(true);

        if (hasBorder) {
            l.setBorder(blackline);
        }

        return l;
    }//end of addLabel()

    public void addObj(Component component,
            GridBagLayout layout, GridBagConstraints c, int gridx, int gridy,
            int gridwidth, int gridheight) { //adds component to overall container

        c.gridx = gridx;
        c.gridy = gridy;

        c.gridwidth = gridwidth;
        c.gridheight = gridheight;

        layout.setConstraints(component, c);
        evidenceContainer.add(component);
    } //end of addObj()
}//end of EvidenceRecord class
