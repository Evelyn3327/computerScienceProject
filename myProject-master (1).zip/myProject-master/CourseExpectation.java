/*
 * Contains a two JTables. One to display student information and one for user
 * to enter student marks for a task. Contains a JComboBox so user can choose
 * what task is marked.
 */
package myproject;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Evelyn He
 */

public class CourseExpectation extends MyProject {

    JPanel studentTblHolder;
    JPanel marksTblHolder;

    DefaultTableModel studentModel = new DefaultTableModel();
    JTable studentTable;
    JScrollPane studentScrollPane;

    DefaultTableModel marksModel;
    JTable marksTable = new JTable();
    JScrollPane marksScrollPane;
    String taskClicked;
    String taskToSave;

    Font labelFont = new Font("Nimbus", Font.BOLD, 14);

    int numColumns = 0;
    int numRows = 0;
    boolean dataHasChanged = false;

    JFrame expectationFrame = super.frame(0,0,600, 560, 1);

    public CourseExpectation(String courseCode, String courseName,
            ArrayList<Expectation> expectations, LinkedHashMap<String, Student> students,
            ArrayList<GeneralTask> tasks, Integer[] numTaskType) {

        super.title(" Assesment & Evaluation - " + courseCode, expectationFrame, super.titleFontSize, 0,true);

        //Panel to hold tables
        studentTblHolder = new JPanel(new BorderLayout());
        studentTblHolder.setBounds(10, 100, 350, 400);
        studentTblHolder.setBackground(Color.BLACK);

        //Create dropdown menu
        addMenuAndTables(courseCode, courseName, expectations, students, tasks);
        
        //Saves information
        JButton save = new JButton("Save");
        save.addActionListener((ActionEvent e) -> {
            dataHasChanged = false;
            try {
                saveButtonPressed(courseCode, courseName, expectations,
                        students, tasks, marksModel, taskToSave, numTaskType);
            } catch (IOException ex) {
                Logger.getLogger(CourseExpectation.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        save.setBounds(175, 48, 80, 40);

        expectationFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (dataHasChanged) {
                    new Popups().confirmExit();
                } else {
                    System.exit(0);
                }
            }
        });

        expectationFrame.add(save);
        expectationFrame.setVisible(true);
    }//end of Constructor

    //Saves new information to file
    public void saveButtonPressed(String courseCode, String courseName,
            ArrayList<Expectation> expectations, LinkedHashMap<String, Student> students,
            ArrayList<GeneralTask> tasks, DefaultTableModel taskModel, 
            String taskToSave, Integer[] numTaskType) throws IOException {

        int row = 0;
        String specificMarks = "";

        //Puts new information from tables into linkedhashmap
        for (String key : students.keySet()) {
            for (int column = 0; column < numColumns; column++) {
                specificMarks = specificMarks + "," + (String) taskModel.getValueAt(row, column);
            }

            specificMarks = specificMarks.substring(1);
            Student theStudent = students.get(key);
            theStudent.marks.put(taskToSave, specificMarks);

            specificMarks = "";
            row++;
        }

        //Writes updated information to file
        File oldFile = new File(courseCode + ".txt");
        String[] filePath = oldFile.getAbsolutePath().split(courseCode);
        oldFile.delete();

        File newFile = new File(courseCode + ".txt");

        FileWriter fw = null;
        BufferedWriter bw = null;
        PrintWriter pw = null;
        try {
            fw = new FileWriter(newFile);
            bw = new BufferedWriter(fw);
            pw = new PrintWriter(bw);

            pw.println("CC " + courseCode);
            pw.println("");
            pw.println("CN " + courseName);
            pw.println("");

            for (int numExp = 0; numExp < expectations.size(); numExp++) {
                pw.print("CE ");
                pw.print(expectations.get(numExp).strand + "%");
                pw.print(expectations.get(numExp).strandName + "%");

                int length = expectations.get(numExp).specificExpectations.length;

                String s = "";
                for (int numSpecific = 0; numSpecific < length; numSpecific++) {
                    s = s + "," + expectations.get(numExp).specificExpectations[numSpecific];
                }
                pw.println(s.substring(1) + "%");
            }
            pw.println("");

            pw.print("TN ");
            for (int i = 0; i < 4; i++) {
                pw.print(numTaskType[i] + "%");
            }
            pw.println("");

            for (int numTask = 0; numTask < tasks.size(); numTask++) {
                pw.print("CT ");
                pw.print(tasks.get(numTask).taskName + "%");
                pw.print(tasks.get(numTask).taskType + "%");

                int length = tasks.get(numTask).taskExpectations.length;
                String s = "";
                for (int numSpecific = 0; numSpecific < length; numSpecific++) {
                    s = s + "," + tasks.get(numTask).taskExpectations[numSpecific];
                }
                pw.println(s.substring(1) + "%");
            }
            pw.println("");

            for (Map.Entry item : students.entrySet()) {
                pw.print("CS ");
                Student theStudent = (Student) item.getValue();
                pw.print(theStudent.studentNumber + "%");
                pw.print(theStudent.firstName + "%");
                pw.println(theStudent.lastName + "%");

                for (Map.Entry taskMarks : theStudent.marks.entrySet()) {
                    pw.print("SM ");
                    pw.print(taskMarks.getKey() + "%");
                    pw.println(taskMarks.getValue() + "%");
                }
            }

        } catch (IOException e) {
            System.out.println(e);

            System.out.println(e);
        } finally {
            try {
                if (fw != null && bw != null && pw != null) {
                    bw.close();
                    fw.close();
                    pw.close();
                }
            } catch (IOException e) {
                System.out.println(e);
            }
        }
        new Popups().sucessfulSave();
    }//end of saveButtonPressed()

    /*Creates dropdown menu which lets user choose which task is getting marked
    Also adds 2 tables where the user can enter marks*/
    private void addMenuAndTables(String courseCode, String courseName,
            ArrayList<Expectation> expectations, LinkedHashMap<String, Student> students,
            ArrayList<GeneralTask> tasks) {

        ArrayList<String> addTask = new ArrayList();
        
        //Gets a list of tasks from arraylist
        for (int i = 0; i < tasks.size(); i++) {
            addTask.add(i, tasks.get(i).taskName);
        }

        JComboBox taskList = new JComboBox();
        DefaultComboBoxModel dml = new DefaultComboBoxModel();

        //Adds tasks to JComboBox
        for (int i = 0; i < addTask.size(); i++) {
            dml.addElement(tasks.get(i).taskType + " - " + addTask.get(i));
        }

        taskList.setModel(dml);
        taskList.setSelectedIndex(0);
        taskToSave = tasks.get(0).taskType;

        //creates tables for student information and marks information
        numRows = studentTable(courseCode, courseName, expectations, students, tasks);
        DefaultTableModel marksModel = marksTable(students, tasks, 0, numRows, taskToSave);

        //connects the 2 tables together
        studentTable.setSelectionModel(marksTable.getSelectionModel());
        studentScrollPane.getVerticalScrollBar().setModel(marksScrollPane.getVerticalScrollBar().getModel());
        taskList.setBounds(10, 48, 150, 40);
        expectationFrame.add(taskList);

        //Changes marks table on when JCombobox is clicked
        taskList.addActionListener((ActionEvent e) -> {
            JComboBox cb = (JComboBox) e.getSource();
            taskClicked = (String) cb.getSelectedItem();
            taskToSave = tasks.get(cb.getSelectedIndex()).taskType;

            //Finds which item in combobox is clicked and calls method to create new table
            for (int i = 0; i < taskList.getItemCount(); i++) {
                if (taskList.getItemAt(i).toString().equals(taskClicked)) {
                    newMarksTable(students, tasks, i, numRows, marksModel, taskToSave);
                }
            }
        });
    }//end of addMenuAndTables()

    //Creates table which is populated by student information
    public int studentTable(String courseCode, String courseName,
            ArrayList<Expectation> expectations, LinkedHashMap<String, Student> students,
            ArrayList<GeneralTask> tasks) {

        JLabel studentTitle = new JLabel(" Student Information");
        studentTitle.setForeground(Color.WHITE);
        studentTitle.setFont(labelFont);
        studentTitle.setSize(350, 100);
        studentTitle.setBorder(blackline);

        studentModel.addColumn("Student Number");
        studentModel.addColumn("First Name");
        studentModel.addColumn("Last Name");

        //Creates table and makes its cells uneditable
        studentTable = new JTable(studentModel) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        studentTable.getColumnModel().getColumn(0).setWidth(200);
        studentTable.getColumnModel().getColumn(1).setWidth(125);
        studentTable.getColumnModel().getColumn(2).setWidth(125);

        studentScrollPane = new JScrollPane(studentTable);
        studentScrollPane.setPreferredSize(new Dimension(350, 200));
        studentScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);

        studentTblHolder.add(studentTitle, BorderLayout.NORTH);
        studentTblHolder.add(studentScrollPane, BorderLayout.WEST);

        //Populates table with information
        ArrayList<Student> list = new ArrayList<>(students.values());

        for (int i = 0; i < students.size(); i++) {
            studentModel.addRow(new Object[]{
                list.get(i).studentNumber,
                list.get(i).firstName,
                list.get(i).lastName
            });
        }
        studentTable.setRowHeight(20);
        studentTable.setShowVerticalLines(true);
        studentTable.setShowHorizontalLines(true);

        //calls on EvidenceRecord class on mouse click
        studentTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {

                    int row = studentTable.getSelectedRow();
                    int column = studentTable.getSelectedColumn();

                    if (column == 0) {
                        String studentNum = list.get(row).studentNumber;

                        new EvidenceRecord(studentNum, courseCode, courseName,
                                expectations, students, tasks);
                    }
                }
            }

        });

        expectationFrame.add(studentTblHolder);

        return students.size();
    }//end of studentTable()

    //Creates a dynamic table for user to enter marks of a task
    public DefaultTableModel marksTable(LinkedHashMap<String, Student> students,
            ArrayList<GeneralTask> tasks, int taskSelected, int numRows, 
            String taskToSave) {

        marksModel = new DefaultTableModel();
        marksTable.setModel(marksModel);

        JLabel marksTitle = new JLabel("Marks");
        marksTitle.setForeground(Color.WHITE);
        marksTitle.setSize(tasks.size() * 25, 100);
        marksTitle.setFont(labelFont);
        marksTitle.setBorder(blackline);

        String[] allExpectations = tasks.get(taskSelected).taskExpectations;
        
        for (int i = 0; i < allExpectations.length; i++) {
            marksModel.addColumn(allExpectations[i]);
            numColumns++;
        }

        for (int i = 0; i < allExpectations.length; i++) {
            marksTable.getColumnModel().getColumn(i).setWidth(25);
        }
        
        marksScrollPane = new JScrollPane(marksTable);
        marksScrollPane.setPreferredSize(new Dimension((allExpectations.length) * 35 + 20, 200));
        marksScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        marksTblHolder = new JPanel(new BorderLayout());
        marksTblHolder.setBounds(360, 100, allExpectations.length * 35 + 20, 400);
        marksTblHolder.setBackground(Color.BLACK);

        marksTblHolder.add(marksTitle, BorderLayout.NORTH);
        marksTblHolder.add(marksScrollPane, BorderLayout.WEST);
        marksTblHolder.setBackground(Color.BLACK);

        //Populates table with previously entered information
        students.keySet().forEach((key) -> {
            String[] row = new String[numColumns];
            String allMarks = students.get(key).marks.get(taskToSave);

            if (allMarks != null) {
                String[] specificMarks = allMarks.split(",");

                for (int i = 0; i < row.length; i++) {
                    row[i] = specificMarks[i];
                }

                marksModel.addRow(row);
            } else {
                marksModel.addRow(new String[]{});
            }
        });

        marksTable.setRowHeight(20);
        marksTable.setShowVerticalLines(true);
        marksTable.setShowHorizontalLines(true);
        changesInData(marksTable);

        expectationFrame.add(marksTblHolder);

        return marksModel;
    }//end of marksTable()

    //Changes structure of the marks table for new task
    public DefaultTableModel newMarksTable(LinkedHashMap<String, Student> students,
            ArrayList<GeneralTask> tasks, int taskSelected, int numRows,
            DefaultTableModel marksModel, String taskToSave) {

        //Removes information from marks table
        marksTblHolder.remove(marksScrollPane);
        numColumns = 0;
        marksModel.setColumnCount(0);
        marksModel.setRowCount(0);
        marksModel.fireTableDataChanged();
        marksModel.fireTableStructureChanged();

        JLabel marksTitle = new JLabel("Marks");
        marksTitle.setSize(tasks.size() * 25, 100);
        marksTitle.setFont(labelFont);
        marksTitle.setBorder(blackline);
        
        //Re-adds new columns
        String[] allExpectations = tasks.get(taskSelected).taskExpectations;

        for (String allExpectation : allExpectations) {
            numColumns++;
            marksModel.addColumn(allExpectation);
        }

        for (int i = 0; i < allExpectations.length; i++) {
            marksTable.getColumnModel().getColumn(i).setWidth(25);
        }

     //   marksTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        
        marksTable.revalidate();

        marksScrollPane = new JScrollPane(marksTable);

        if (allExpectations.length < 6) {
            marksScrollPane.setPreferredSize(new Dimension(allExpectations.length * 35 + 20, 200));
            marksTblHolder.setBounds(360, 100, allExpectations.length * 35 + 20, 400);
        } else {
            marksTable.setPreferredScrollableViewportSize(new Dimension(195,200));
            marksScrollPane.setPreferredSize(new Dimension(195, 200));
            marksTblHolder.setBounds(360, 100, 195, 400);
        }

        marksScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        studentScrollPane.getVerticalScrollBar().setModel(marksScrollPane.getVerticalScrollBar().getModel());
        marksScrollPane.revalidate();

        marksTblHolder.setBackground(Color.BLACK);
        marksTblHolder.revalidate();

        marksTblHolder.add(marksTitle, BorderLayout.NORTH);
        marksTblHolder.add(marksScrollPane, BorderLayout.WEST);

        //populates table with previously-entered information
        students.keySet().forEach((key) -> {
            String[] row = new String[numColumns];
            String allMarks = students.get(key).marks.get(taskToSave);

            if (allMarks != null) {
                String[] specificMarks = allMarks.split(",");

                System.arraycopy(specificMarks, 0, row, 0, row.length);

                marksModel.addRow(row);
            } else {
                marksModel.addRow(new String[]{});

            }
        });

        marksTable.setRowHeight(20);
        marksTable.setShowVerticalLines(true);
        marksTable.setShowHorizontalLines(true);
        changesInData(marksTable);

        marksModel.fireTableRowsUpdated(0, numRows - 1);
        marksModel.fireTableStructureChanged();

        return marksModel;

    }//end of newMarksTable()

    //Checks to see if there have been any edits
    public void changesInData(JTable table) {
        table.getModel().addTableModelListener((TableModelEvent e) -> {
            if (table.isEditing()) {
                dataHasChanged = true;
            }
        });
    }//end of changesInData()
}//end of CourseExpectation class
